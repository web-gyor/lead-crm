-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: lead_crm
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  `lead_id` int DEFAULT NULL,
  `description` text,
  `old_value` text,
  `new_value` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,NULL,'System Root','LEAD_INGESTION',NULL,'New lead John Doe ingested into the system.',NULL,NULL,'2026-05-22 02:15:20'),(2,NULL,'Admin User','STATUS_UPDATE',NULL,'Status changed to \"Contacted\" for Alice Smith.',NULL,NULL,'2026-05-22 02:15:20'),(3,NULL,'Counselor A','NOTE_ADDED',NULL,'Added a follow-up note: Interested in UK universities.',NULL,NULL,'2026-05-22 02:15:20'),(4,NULL,'Admin User','ASSIGNED',NULL,'Lead Charlie Brown assigned to Counselor B.',NULL,NULL,'2026-05-22 02:15:20'),(5,NULL,'Counselor B','STATUS_UPDATE',NULL,'Status changed to \"Document Verification\" for Diana Prince.',NULL,NULL,'2026-05-22 02:15:20'),(6,3,NULL,'ASSIGNED',264,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:37:13'),(7,3,NULL,'ASSIGNED',268,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:37:13'),(8,3,NULL,'ASSIGNED',268,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:37:15'),(9,3,NULL,'ASSIGNED',264,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:37:15'),(10,3,NULL,'ASSIGNED',264,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:42:16'),(11,3,NULL,'ASSIGNED',268,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:42:16'),(12,3,NULL,'ASSIGNED',264,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:42:17'),(13,3,NULL,'ASSIGNED',268,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 16:42:17'),(14,3,NULL,'ASSIGNED',262,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 16:51:34'),(15,3,NULL,'ASSIGNED',263,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 16:51:34'),(16,3,NULL,'ASSIGNED',262,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 16:51:34'),(17,3,NULL,'ASSIGNED',263,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 16:51:34'),(18,3,NULL,'ASSIGNED',262,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 17:02:12'),(19,3,NULL,'ASSIGNED',263,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 17:02:12'),(20,3,NULL,'ASSIGNED',246,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 17:16:16'),(21,3,NULL,'ASSIGNED',245,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 17:16:16'),(22,3,NULL,'ASSIGNED',245,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:16:41'),(23,3,NULL,'ASSIGNED',246,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:16:41'),(24,3,NULL,'ASSIGNED',242,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 17:17:05'),(25,3,NULL,'ASSIGNED',244,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-23 17:17:05'),(26,3,NULL,'ASSIGNED',242,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:17:20'),(27,3,NULL,'ASSIGNED',244,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:17:20'),(28,3,NULL,'ASSIGNED',238,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:17:47'),(29,3,NULL,'ASSIGNED',239,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:17:47'),(30,3,NULL,'ASSIGNED',245,'Bulk assigned to Ragesh  with status \"New\"',NULL,'21','2026-05-23 17:18:14'),(31,3,NULL,'ASSIGNED',246,'Bulk assigned to Ragesh  with status \"New\"',NULL,'21','2026-05-23 17:18:14'),(32,3,NULL,'ASSIGNED',245,'Bulk assigned to Kavya  with status \"New\"',NULL,'20','2026-05-23 17:18:22'),(33,3,NULL,'ASSIGNED',246,'Bulk assigned to Kavya  with status \"New\"',NULL,'20','2026-05-23 17:18:22'),(34,3,NULL,'ASSIGNED',245,'Bulk assigned to Suman with status \"New\"',NULL,'9','2026-05-23 17:18:32'),(35,3,NULL,'ASSIGNED',246,'Bulk assigned to Suman with status \"New\"',NULL,'9','2026-05-23 17:18:32'),(36,3,NULL,'ASSIGNED',245,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:18:41'),(37,3,NULL,'ASSIGNED',246,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:18:41'),(38,3,NULL,'ASSIGNED',245,'Bulk assigned to Kavya  with status \"New\"',NULL,'20','2026-05-23 17:19:40'),(39,3,NULL,'ASSIGNED',246,'Bulk assigned to Kavya  with status \"New\"',NULL,'20','2026-05-23 17:19:40'),(40,3,NULL,'ASSIGNED',245,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:21:14'),(41,3,NULL,'ASSIGNED',246,'Bulk assigned to Anil  with status \"New\"',NULL,'1','2026-05-23 17:21:14'),(42,3,NULL,'ASSIGNED',245,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-24 02:46:23'),(43,3,NULL,'ASSIGNED',246,'Bulk assigned to Ramya with status \"New\"',NULL,'7','2026-05-24 02:46:23'),(44,3,NULL,'ASSIGNED',244,'Bulk assigned to Madhu with status \"New\"',NULL,'6','2026-05-24 04:07:11'),(45,3,NULL,'ASSIGNED',242,'Bulk assigned to Madhu with status \"New\"',NULL,'6','2026-05-24 04:07:11');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_logs_archive`
--

DROP TABLE IF EXISTS `activity_logs_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs_archive` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  `lead_id` int DEFAULT NULL,
  `description` text,
  `old_value` text,
  `new_value` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `archived_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs_archive`
--

LOCK TABLES `activity_logs_archive` WRITE;
/*!40000 ALTER TABLE `activity_logs_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archived_leads`
--

DROP TABLE IF EXISTS `archived_leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `archived_leads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_source_id` bigint DEFAULT NULL,
  `lead_source_detail` varchar(255) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `parent_name` varchar(255) DEFAULT NULL,
  `parent_contact` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `whatsapp_same` tinyint(1) DEFAULT '1',
  `alternate_phone` varchar(20) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` enum('Male','Female','Other','Prefer not to say') DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `year_of_passing` year DEFAULT NULL,
  `city` varchar(80) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'India',
  `area_locality` varchar(120) DEFAULT NULL,
  `counselor_remarks` text,
  `interested_course` varchar(255) DEFAULT NULL,
  `urgency` enum('Hot','Urgent','This Week','This Month','Researching') DEFAULT 'Researching',
  `referred_by_name` varchar(100) DEFAULT NULL,
  `referred_by_phone` varchar(15) DEFAULT NULL,
  `referred_by_type` enum('Doctor','Patient','Friend/Family','Staff','Other') DEFAULT NULL,
  `lead_status` varchar(50) DEFAULT 'New',
  `is_archived` tinyint(1) DEFAULT '1',
  `lead_quality` enum('hot','warm','cold','unverified','low') DEFAULT 'unverified',
  `next_follow_up_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `first_contacted_at` datetime DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `converted_at` datetime DEFAULT NULL,
  `assigned_user_id` int DEFAULT NULL,
  `lead_uid` varchar(15) DEFAULT NULL,
  `source_project` varchar(100) DEFAULT NULL,
  `assignment_mode` varchar(50) DEFAULT 'manual',
  `assignment_reason` varchar(255) DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT NULL,
  `lost_at` datetime DEFAULT NULL,
  `status_updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `last_interaction_at` datetime DEFAULT NULL,
  `lead_score` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_full_name` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archived_leads`
--

LOCK TABLES `archived_leads` WRITE;
/*!40000 ALTER TABLE `archived_leads` DISABLE KEYS */;
INSERT INTO `archived_leads` VALUES (1,NULL,NULL,'Adarsh Nair',NULL,NULL,'9847000001',1,NULL,'adarsh@example.com',NULL,NULL,NULL,NULL,'Kozhikode','India',NULL,'Old inquiry from 2025','Digital Marketing','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-01-10 10:00:00',NULL,NULL,'2025-01-10 10:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(2,NULL,NULL,'Sruthi Das',NULL,NULL,'9847000002',1,NULL,'sruthi@example.com',NULL,NULL,NULL,NULL,'Kochi','India',NULL,'Fee issue','Python Full Stack','Researching',NULL,NULL,NULL,'Not Interested',1,'',NULL,'2025-01-12 11:30:00',NULL,NULL,'2025-01-12 11:30:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(3,NULL,NULL,'Rahul Varma',NULL,NULL,'9847000003',1,NULL,'rahul@example.com',NULL,NULL,NULL,NULL,'Trivandrum','India',NULL,'Joined elsewhere','Data Science','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-01-15 09:15:00',NULL,NULL,'2025-01-15 09:15:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(4,NULL,NULL,'Anjali Menon',NULL,NULL,'9847000004',1,NULL,'anjali@example.com',NULL,NULL,NULL,NULL,'Calicut','India',NULL,'No response','UI/UX Design','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-01-20 14:45:00',NULL,NULL,'2025-01-20 14:45:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(5,NULL,NULL,'Muhammed Fazil',NULL,NULL,'9847000005',1,NULL,'fazil@example.com',NULL,NULL,NULL,NULL,'Malappuram','India',NULL,'Distance issue','MERN Stack','Researching',NULL,NULL,NULL,'Not Interested',1,'',NULL,'2025-01-25 16:20:00',NULL,NULL,'2025-01-25 16:20:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(6,NULL,NULL,'Sneha George',NULL,NULL,'9847000006',1,NULL,'sneha@example.com',NULL,NULL,NULL,NULL,'Thrissur','India',NULL,'Outdated lead','Digital Marketing','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-02-01 10:00:00',NULL,NULL,'2025-02-01 10:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(7,NULL,NULL,'Arjun K',NULL,NULL,'9847000007',1,NULL,'arjun@example.com',NULL,NULL,NULL,NULL,'Kannur','India',NULL,'Not reachable','Python Full Stack','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-02-05 11:00:00',NULL,NULL,'2025-02-05 11:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(8,NULL,NULL,'Meera Pillai',NULL,NULL,'9847000008',1,NULL,'meera@example.com',NULL,NULL,NULL,NULL,'Kollam','India',NULL,'Job placement concern','Data Science','Researching',NULL,NULL,NULL,'Not Interested',1,'',NULL,'2025-02-10 12:00:00',NULL,NULL,'2025-02-10 12:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(9,NULL,NULL,'Deepak Raj',NULL,NULL,'9847000009',1,NULL,'deepak@example.com',NULL,NULL,NULL,NULL,'Palakkad','India',NULL,'Moved to Bangalore','UI/UX Design','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-02-15 13:00:00',NULL,NULL,'2025-02-15 13:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(31,NULL,NULL,'Adarsh Nair',NULL,NULL,'9847000001',1,NULL,'adarsh@example.com',NULL,NULL,NULL,NULL,'Kozhikode','India',NULL,'Archive test from 2025','Digital Marketing','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-01-10 10:00:00',NULL,NULL,'2025-01-10 10:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(32,NULL,NULL,'Sruthi Das',NULL,NULL,'9847000002',1,NULL,'sruthi@example.com',NULL,NULL,NULL,NULL,'Kochi','India',NULL,'Archive test: Fee issue','Python Full Stack','Researching',NULL,NULL,NULL,'Not Interested',1,'low',NULL,'2025-01-12 11:30:00',NULL,NULL,'2025-01-12 11:30:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(33,NULL,NULL,'Rahul Varma',NULL,NULL,'9847000003',1,NULL,'rahul@example.com',NULL,NULL,NULL,NULL,'Trivandrum','India',NULL,'Archive test: Joined elsewhere','Data Science','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-01-15 09:15:00',NULL,NULL,'2025-01-15 09:15:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(34,NULL,NULL,'Anjali Menon',NULL,NULL,'9847000004',1,NULL,'anjali@example.com',NULL,NULL,NULL,NULL,'Calicut','India',NULL,'Archive test: No response','UI/UX Design','Researching',NULL,NULL,NULL,'Lost',1,'hot',NULL,'2025-01-20 14:45:00',NULL,NULL,'2025-01-20 14:45:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(35,NULL,NULL,'Muhammed Fazil',NULL,NULL,'9847000005',1,NULL,'fazil@example.com',NULL,NULL,NULL,NULL,'Malappuram','India',NULL,'Archive test: Distance','MERN Stack','Researching',NULL,NULL,NULL,'Not Interested',1,'low',NULL,'2025-01-25 16:20:00',NULL,NULL,'2025-01-25 16:20:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(36,NULL,NULL,'Sneha George',NULL,NULL,'9847000006',1,NULL,'sneha@example.com',NULL,NULL,NULL,NULL,'Thrissur','India',NULL,'Archive test: Outdated','Digital Marketing','Researching',NULL,NULL,NULL,'Lost',1,'warm',NULL,'2025-02-01 10:00:00',NULL,NULL,'2025-02-01 10:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(37,NULL,NULL,'Arjun K',NULL,NULL,'9847000007',1,NULL,'arjun@example.com',NULL,NULL,NULL,NULL,'Kannur','India',NULL,'Archive test: Not reachable','Python Full Stack','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-02-05 11:00:00',NULL,NULL,'2025-02-05 11:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(38,NULL,NULL,'Meera Pillai',NULL,NULL,'9847000008',1,NULL,'meera@example.com',NULL,NULL,NULL,NULL,'Kollam','India',NULL,'Archive test: Job concern','Data Science','Researching',NULL,NULL,NULL,'Not Interested',1,'low',NULL,'2025-02-10 12:00:00',NULL,NULL,'2025-02-10 12:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(39,NULL,NULL,'Deepak Raj',NULL,NULL,'9847000009',1,NULL,'deepak@example.com',NULL,NULL,NULL,NULL,'Palakkad','India',NULL,'Archive test: Moved','UI/UX Design','Researching',NULL,NULL,NULL,'Lost',1,'cold',NULL,'2025-02-15 13:00:00',NULL,NULL,'2025-02-15 13:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0),(40,NULL,NULL,'Fathima Beevi',NULL,NULL,'9847000010',1,NULL,'fathima@example.com',NULL,NULL,NULL,NULL,'Alappuzha','India',NULL,'Archive test: Waiting','MERN Stack','Researching',NULL,NULL,NULL,'Lost',1,'warm',NULL,'2025-02-20 14:00:00',NULL,NULL,'2025-02-20 14:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `archived_leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `date` date NOT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime DEFAULT NULL,
  `work_mode` enum('office','wfh','on_field') DEFAULT 'office',
  `location_data` text,
  `status` varchar(50) DEFAULT 'Present',
  `total_hours` decimal(5,2) DEFAULT '0.00',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_user_attendance` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (1,3,'2026-05-10','2026-05-10 13:51:21','2026-05-10 22:51:21','wfh','{\"timestamp\":\"2026-05-10T02:51:21.159Z\"}','Present',0.00,'2026-05-10 08:21:21'),(2,6,'2026-05-10','2026-05-10 13:53:43','2026-05-10 22:53:43','wfh','{\"timestamp\":\"2026-05-10T02:53:43.493Z\"}','Present',0.00,'2026-05-10 08:23:43'),(3,2,'2026-05-10','2026-05-10 13:54:11','2026-05-10 22:54:11','wfh','{\"timestamp\":\"2026-05-10T02:54:11.892Z\"}','Present',0.00,'2026-05-10 08:24:11'),(4,3,'2026-05-11','2026-05-12 00:47:53','2026-05-12 00:49:38','office','{\"timestamp\":\"2026-05-11T13:47:53.926Z\"}','Present',0.00,'2026-05-11 19:17:53'),(5,1,'2026-05-08','2026-05-08 09:00:00','2026-05-08 18:00:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(6,1,'2026-05-09','2026-05-09 09:10:00','2026-05-09 18:05:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(7,1,'2026-05-11','2026-05-11 09:05:00','2026-05-11 18:00:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(8,2,'2026-05-08','2026-05-08 09:25:00','2026-05-08 13:00:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(9,2,'2026-05-08','2026-05-08 14:00:00','2026-05-08 18:15:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(10,2,'2026-05-09','2026-05-09 09:45:00','2026-05-09 18:00:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(11,2,'2026-05-11','2026-05-11 09:12:00','2026-05-11 17:30:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(12,3,'2026-05-08','2026-05-08 09:00:00','2026-05-08 13:00:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(13,3,'2026-05-09','2026-05-09 10:30:00','2026-05-09 18:00:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(14,3,'2026-05-11','2026-05-11 13:00:00','2026-05-11 18:00:00','office',NULL,'present',0.00,'2026-05-11 19:25:58'),(28,7,'2026-05-10','2026-05-10 09:05:00','2026-05-10 18:05:00','office',NULL,'present',0.00,'2026-05-11 19:30:38'),(29,1,'2026-05-22','2026-05-22 09:00:00',NULL,'office',NULL,'Present',0.00,'2026-05-22 08:12:02'),(30,1,'2026-05-21','2026-05-21 09:30:00',NULL,'office',NULL,'Present',0.00,'2026-05-22 08:12:02'),(31,1,'2026-05-20','2026-05-20 08:45:00',NULL,'office',NULL,'Present',0.00,'2026-05-22 08:12:02'),(32,3,'2026-05-22','2026-05-22 14:11:41',NULL,'wfh','{\"timestamp\":\"2026-05-22T03:11:41.865Z\"}','Present',0.00,'2026-05-22 08:41:41');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `automation_queue`
--

DROP TABLE IF EXISTS `automation_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `automation_queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lead_id` int NOT NULL,
  `template_id` int NOT NULL,
  `type` enum('whatsapp','sms','email') NOT NULL,
  `scheduled_for` datetime NOT NULL,
  `status` enum('pending','sent','failed','cancelled') DEFAULT 'pending',
  `error_message` text,
  `retry_count` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `template_id` (`template_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `automation_queue`
--

LOCK TABLES `automation_queue` WRITE;
/*!40000 ALTER TABLE `automation_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `automation_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `automation_rules`
--

DROP TABLE IF EXISTS `automation_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `automation_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('whatsapp','sms','email') NOT NULL,
  `trigger_status` varchar(50) NOT NULL,
  `delay_value` int DEFAULT '0',
  `delay_unit` enum('minutes','hours','days') DEFAULT 'minutes',
  `template_id` int NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `automation_rules`
--

LOCK TABLES `automation_rules` WRITE;
/*!40000 ALTER TABLE `automation_rules` DISABLE KEYS */;
INSERT INTO `automation_rules` VALUES (1,'Immediate Welcome WA','whatsapp','New',0,'minutes',1,1,'2026-05-15 07:23:08','2026-05-15 07:23:08'),(2,'Interested Course Brochure','whatsapp','Interested',2,'hours',2,1,'2026-05-15 07:23:08','2026-05-15 07:23:08'),(3,'24h Follow-up Reminder','whatsapp','Follow-up',24,'hours',3,1,'2026-05-15 07:23:08','2026-05-15 12:21:34'),(4,'DND Re-engagement','whatsapp','DND',7,'days',4,1,'2026-05-15 07:23:08','2026-05-15 12:21:34'),(5,'Converted Welcome Kit','whatsapp','Converted',0,'minutes',5,1,'2026-05-15 07:23:08','2026-05-15 12:21:35'),(6,'Day 1: Company Profile','email','New',1,'days',6,1,'2026-05-15 07:23:17','2026-05-15 07:23:17'),(7,'Day 3: Syllabus PDF','email','Interested',3,'days',7,1,'2026-05-15 07:23:17','2026-05-15 07:23:17'),(8,'Missed Call - Schedule Link','email','Contacted',4,'hours',8,1,'2026-05-15 07:23:17','2026-05-15 07:23:17'),(9,'Monthly Training Newsletter','email','Lost',30,'days',9,1,'2026-05-15 07:23:17','2026-05-15 07:23:17'),(10,'Onboarding: Login Credentials','email','Converted',10,'minutes',10,1,'2026-05-15 07:23:17','2026-05-15 07:23:17'),(11,'New Inquiry SMS Alert','sms','New',1,'minutes',11,1,'2026-05-15 07:23:28','2026-05-15 07:23:28'),(12,'Urgent Call-back Request','sms','Follow-up',3,'hours',12,1,'2026-05-15 07:23:28','2026-05-15 07:23:28'),(13,'Payment Received Alert','sms','Converted',0,'minutes',13,1,'2026-05-15 07:23:28','2026-05-15 07:23:28'),(14,'Limited Batch Seats Alert','sms','Interested',5,'days',14,1,'2026-05-15 07:23:28','2026-05-15 07:23:28'),(15,'Re-activation Promo','sms','Lost',15,'days',15,1,'2026-05-15 07:23:28','2026-05-15 07:23:28'),(16,'Immediate welcom','whatsapp','Contacted',2,'minutes',29,1,'2026-05-15 08:45:52','2026-05-15 12:21:35');
/*!40000 ALTER TABLE `automation_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_logs`
--

DROP TABLE IF EXISTS `call_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lead_id` int NOT NULL,
  `user_id` int NOT NULL,
  `call_sid` varchar(100) DEFAULT NULL,
  `direction` enum('outbound','inbound') DEFAULT 'outbound',
  `duration` int DEFAULT '0',
  `recording_url` text,
  `call_status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` datetime DEFAULT NULL,
  `admin_feedback` text,
  `admin_rating` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `call_sid` (`call_sid`),
  KEY `lead_id` (`lead_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_logs`
--

LOCK TABLES `call_logs` WRITE;
/*!40000 ALTER TABLE `call_logs` DISABLE KEYS */;
INSERT INTO `call_logs` VALUES (11,11,1,'NEW_LOG_003','inbound',200,NULL,NULL,'2026-05-22 04:22:58',NULL,'Technical discussion',0),(5,11,1,'SID_NON_REC_001','outbound',32,'https://www.w3schools.com/html/horse.mp3',NULL,'2026-05-22 04:01:30',NULL,NULL,0),(10,11,1,'NEW_LOG_002','outbound',45,NULL,NULL,'2026-05-22 04:22:58',NULL,'Follow-up call',0),(9,11,1,'NEW_LOG_001','inbound',120,NULL,NULL,'2026-05-22 04:22:58',NULL,'Initial inquiry',0);
/*!40000 ALTER TABLE `call_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_integrations`
--

DROP TABLE IF EXISTS `client_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_integrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `source_key` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT '0',
  `config_data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_integration` (`client_id`,`source_key`),
  UNIQUE KEY `uq_client_source` (`client_id`,`source_key`),
  CONSTRAINT `chk_source_key` CHECK ((`source_key` in (_utf8mb4'meta',_utf8mb4'whatsapp',_utf8mb4'google',_utf8mb4'website',_utf8mb4'linkedin')))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_integrations`
--

LOCK TABLES `client_integrations` WRITE;
/*!40000 ALTER TABLE `client_integrations` DISABLE KEYS */;
INSERT INTO `client_integrations` VALUES (1,1,'website',1,'{\"apiKey\": \"WG-TEST-123\"}','2026-05-08 07:53:24','2026-05-08 07:53:24'),(2,1,'meta',1,'{\"verifyToken\": \"webgyor_secret_2026\"}','2026-05-08 12:28:14','2026-05-10 14:45:42');
/*!40000 ALTER TABLE `client_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `communication_logs`
--

DROP TABLE IF EXISTS `communication_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `communication_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lead_id` int NOT NULL,
  `user_id` int NOT NULL,
  `type` enum('Call','WhatsApp','Meeting','Note') DEFAULT 'Call',
  `summary` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `communication_logs`
--

LOCK TABLES `communication_logs` WRITE;
/*!40000 ALTER TABLE `communication_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `communication_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `communication_templates`
--

DROP TABLE IF EXISTS `communication_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `communication_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `category` enum('General','Follow-up','Admission','Payment','Reminder','Support','Custom','Documentation','Visa Update','Interview','Marketing') DEFAULT 'General',
  `message` text NOT NULL,
  `type` enum('whatsapp','sms','email') DEFAULT 'whatsapp',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `communication_templates`
--

LOCK TABLES `communication_templates` WRITE;
/*!40000 ALTER TABLE `communication_templates` DISABLE KEYS */;
INSERT INTO `communication_templates` VALUES (36,'Welcome Email','General','Welcome to {{company}} – Study Abroad Assistance\nDear {{name}},\n\nThank you for contacting {{company}}.\n\nWe are excited to assist you with your study abroad journey. Our expert counselors will guide you through admissions, visa processing, scholarships, and university selection.\n\nPlease feel free to reply to this email for any assistance.\n\nBest Regards,\n{{company}}','email',1,'2026-05-15 05:23:42','2026-05-15 05:23:42'),(32,'Appointment Reminder','General','Reminder: Your counseling session with {{company}} is scheduled on {{date}} at {{time}}.','sms',1,'2026-05-15 05:21:16','2026-05-15 05:21:16'),(41,'fdgdfg','Reminder','vcbcvb','sms',1,'2026-05-15 05:41:00','2026-05-15 05:41:00'),(23,'vnbv','Admission','vbnvb','email',1,'2026-05-14 17:44:15','2026-05-14 17:44:15'),(25,'Initial Inquiry Follow-up','Follow-up','Thank you for contacting {{company}} regarding studying abroad.\n\nOur counselor will guide you with:\n• Country selection\n• Course options\n• Visa support\n• Scholarship opportunities\n\nPlease reply with your preferred destination country.\n\nThank you.','whatsapp',1,'2026-05-15 05:13:41','2026-05-15 05:13:41'),(26,'Counseling Session Reminder','Reminder','Hi {{name}},\n\nThis is a reminder for your counseling session with {{company}} on {{date}} at {{time}}.\n\nPlease be available on time.\n\nThank you.','whatsapp',1,'2026-05-15 05:14:48','2026-05-15 05:19:32'),(28,'Document Submission Reminder','Reminder','Hi {{name}},\n\nKindly submit your pending documents for your study abroad application process.\n\nRequired documents may include:\n• Passport\n• Academic certificates\n• IELTS/PTE score\n• Resume\n\nPlease contact us if you need assistance.\n\n{{company}}','whatsapp',1,'2026-05-15 05:16:18','2026-05-15 05:19:18'),(29,'Application Status Update','Admission','Hi {{name}},\n\nYour application for {{course}} is currently under processing.\n\nOur team will update you once we receive confirmation from the university.\n\nThank you for choosing {{company}}.','whatsapp',1,'2026-05-15 05:16:43','2026-05-15 05:19:09'),(30,'Visa Approval Congratulations','Visa Update','Congratulations {{name}} 🎉\n\nYour student visa process has been successfully completed.\n\nWe wish you a successful academic journey abroad.\n\nThank you for trusting {{company}}.','whatsapp',1,'2026-05-15 05:17:08','2026-05-15 05:18:54'),(33,'Document Reminder','Reminder','Hi {{name}}, please submit your pending application documents to continue your admission process.','sms',1,'2026-05-15 05:21:39','2026-05-15 05:21:39'),(34,'IELTS/PTE Promotion','','Planning to study abroad? Join IELTS/PTE coaching at {{company}}. Contact us for upcoming batches.','sms',1,'2026-05-15 05:21:57','2026-05-15 05:21:57'),(35,'Visa Approved','General','Congratulations {{name}}! Your student visa process is completed successfully. Best wishes from {{company}}.','sms',1,'2026-05-15 05:22:18','2026-05-15 05:22:18'),(37,'Counseling Appointment Email','General','Counseling Session Confirmation\nDear {{name}},\n\nYour counseling session with {{company}} has been scheduled on {{date}} at {{time}}.\n\nPlease keep your academic documents ready for better guidance.\n\nThank you.','email',1,'2026-05-15 05:24:17','2026-05-15 05:24:17'),(38,'Document Submission Email','General','Pending Documents Required\nDear {{name}},\n\nTo continue your application process, please submit the following pending documents:\n\n• Passport Copy\n• Academic Certificates\n• English Test Scores\n• Resume\n\nPlease contact us if you require support.\n\nRegards,\n{{company}}','email',1,'2026-05-15 05:24:44','2026-05-15 05:24:44'),(39,'Offer Letter Update','General','University Application Update\nDear {{name}},\n\nWe are pleased to inform you that your application for {{course}} has progressed successfully.\n\nOur team will share the next steps shortly.\n\nThank you for choosing {{company}}.','email',1,'2026-05-15 05:25:19','2026-05-15 05:25:19'),(40,'Visa Approval Email','General','Congratulations – Visa Approved\nDear {{name}},\n\nCongratulations on your student visa approval.\n\nWe are delighted to be part of your international education journey and wish you success in your future studies.\n\nBest Wishes,\n{{company}}','email',1,'2026-05-15 05:25:44','2026-05-15 05:25:44');
/*!40000 ALTER TABLE `communication_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `counselor_distribution_rules`
--

DROP TABLE IF EXISTS `counselor_distribution_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `counselor_distribution_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `max_active_leads` int DEFAULT '50',
  `course_specialization` json DEFAULT NULL,
  `country_specialization` json DEFAULT NULL,
  `priority_order` int DEFAULT '1',
  `is_active` tinyint(1) DEFAULT '1',
  `last_assigned_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `assignment_mode` enum('round_robin','fixed','manual') DEFAULT 'round_robin',
  `accepts_all_courses` tinyint(1) DEFAULT '0',
  `accepts_all_countries` tinyint(1) DEFAULT '0',
  `daily_limit` int DEFAULT '20',
  `daily_assigned_count` int DEFAULT '0',
  `active_lead_count` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_priority` (`priority_order`),
  CONSTRAINT `fk_distribution_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `counselor_distribution_rules`
--

LOCK TABLES `counselor_distribution_rules` WRITE;
/*!40000 ALTER TABLE `counselor_distribution_rules` DISABLE KEYS */;
INSERT INTO `counselor_distribution_rules` VALUES (1,1,100,NULL,NULL,10,1,'2026-05-12 19:46:27','2026-05-07 10:33:07','2026-05-12 14:16:27','round_robin',0,0,50,11,11),(2,2,100,NULL,NULL,10,1,'2026-05-12 19:46:27','2026-05-07 10:33:07','2026-05-12 14:16:27','round_robin',0,0,50,9,9),(3,6,100,NULL,NULL,10,1,'2026-05-12 19:46:27','2026-05-07 10:33:07','2026-05-12 14:16:27','round_robin',0,0,50,5,5),(4,7,100,NULL,NULL,10,1,'2026-05-12 19:46:27','2026-05-07 10:33:07','2026-05-12 14:16:27','round_robin',0,0,50,5,5);
/*!40000 ALTER TABLE `counselor_distribution_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `country_name` (`country_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'India',1),(2,'UAE',1),(5,'UK',1),(6,'Saudi Arabia',1);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `fee` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'NEET Crash Course 2027','NEET-26',25000.00,'2026-03-24 06:09:16',1),(3,'NEET COURSE TWO','NEET-27',24000.00,'2026-03-24 06:13:31',1),(4,'MERN Stack Development','NEET-25',25000.00,'2026-03-26 11:54:26',1),(5,'Digital Marketing','NEET-22',35000.00,'2026-03-26 11:54:26',1),(6,'UI/UX Design Pro','NEET-18',40000.00,'2026-03-26 11:54:26',1),(7,'Python Django Backend','NEET-21',24000.00,'2026-03-26 11:54:26',1),(8,'Flutter App Development','NEET23',30000.00,'2026-03-26 11:54:26',1),(10,'IAS COACHING','NEET-29',50000.00,'2026-04-10 13:37:22',1);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_assignment_logs`
--

DROP TABLE IF EXISTS `lead_assignment_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_assignment_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lead_id` int NOT NULL,
  `assigned_to` int NOT NULL,
  `assignment_mode` enum('round_robin','fixed','course_based','country_based','manual') DEFAULT 'round_robin',
  `assignment_reason` varchar(255) DEFAULT NULL,
  `assigned_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_id` (`lead_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_assignment_logs`
--

LOCK TABLES `lead_assignment_logs` WRITE;
/*!40000 ALTER TABLE `lead_assignment_logs` DISABLE KEYS */;
INSERT INTO `lead_assignment_logs` VALUES (1,176,1,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:43:57'),(2,177,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:43:59'),(3,178,6,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:01'),(4,179,7,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:03'),(5,180,1,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:05'),(6,181,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:06'),(7,182,6,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:08'),(8,183,7,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:10'),(9,184,1,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:12'),(10,185,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:14'),(11,186,6,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:44:16'),(12,187,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:58:36'),(13,188,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:58:38'),(14,189,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:58:40'),(15,190,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 15:58:42'),(16,191,7,'round_robin','Automated assignment via round_robin',3,'2026-05-07 16:14:59'),(17,192,1,'round_robin','Automated assignment via round_robin',3,'2026-05-07 16:15:01'),(18,193,6,'round_robin','Automated assignment via round_robin',3,'2026-05-07 16:15:02'),(19,194,2,'round_robin','Automated assignment via round_robin',3,'2026-05-07 16:15:04'),(20,195,7,'round_robin','Automated assignment via round_robin',3,'2026-05-07 16:15:06'),(21,222,1,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(22,223,6,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(23,224,2,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(24,225,7,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(25,226,1,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(26,227,1,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(27,228,1,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(28,229,1,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(29,230,1,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27'),(30,231,1,'round_robin','Automated assignment via round_robin',3,'2026-05-12 14:16:27');
/*!40000 ALTER TABLE `lead_assignment_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_follow_ups`
--

DROP TABLE IF EXISTS `lead_follow_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_follow_ups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_id` bigint NOT NULL,
  `follow_up_date` datetime NOT NULL,
  `method` enum('WhatsApp','Call','SMS','Email','In-person') NOT NULL,
  `notes` text,
  `status` enum('Pending','Completed','No Response','Converted') DEFAULT 'Pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_follow_ups`
--

LOCK TABLES `lead_follow_ups` WRITE;
/*!40000 ALTER TABLE `lead_follow_ups` DISABLE KEYS */;
INSERT INTO `lead_follow_ups` VALUES (1,208,'2026-05-11 00:00:00','Call','Initial follow-up regarding website inquiry','Pending','2026-05-11 15:49:20',NULL),(2,207,'2026-05-11 00:00:00','Call','Scheduled follow-up','Pending','2026-05-11 16:12:47',NULL),(3,206,'2026-05-11 00:00:00','Call','Scheduled follow-up','Pending','2026-05-11 16:12:47',NULL);
/*!40000 ALTER TABLE `lead_follow_ups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_interactions`
--

DROP TABLE IF EXISTS `lead_interactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_interactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lead_id` int NOT NULL,
  `interaction_type` enum('Call','WhatsApp','Email','Note') NOT NULL,
  `outcome` enum('Connected','Not Reachable','Switched Off','Sent','Replied','No Response','Interested','Busy') NOT NULL,
  `remarks` text,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_interactions`
--

LOCK TABLES `lead_interactions` WRITE;
/*!40000 ALTER TABLE `lead_interactions` DISABLE KEYS */;
INSERT INTO `lead_interactions` VALUES (1,305,'Call','Connected','fdgfg',3,'2026-05-26 12:13:40'),(2,305,'WhatsApp','Sent','fdgfd',3,'2026-05-26 12:13:49'),(3,305,'Call','Connected','vvbc',3,'2026-05-26 12:16:05'),(4,305,'WhatsApp','Sent','fsdf',3,'2026-05-26 12:16:11'),(5,305,'Call','Connected','fdfdgfd',3,'2026-05-26 12:17:08'),(6,305,'WhatsApp','Sent','ffdsf',3,'2026-05-26 12:17:12'),(7,305,'Call','Connected','tyyt',3,'2026-05-26 12:24:56'),(8,305,'WhatsApp','Sent','tyuytu',3,'2026-05-26 12:25:04'),(9,305,'Note','Connected','tytyu',3,'2026-05-26 12:25:09'),(10,305,'Call','Connected','gfhfghg',3,'2026-05-26 12:26:41'),(11,305,'Call','Connected','sfdsfsd',3,'2026-05-26 12:27:56'),(12,305,'Call','Connected','dfdf',3,'2026-05-26 12:30:12'),(13,305,'WhatsApp','Sent','fghgfh',3,'2026-05-26 12:30:17'),(14,305,'Note','Connected','fghfgh',3,'2026-05-26 12:30:23'),(15,305,'Note','Connected','fghfgh',3,'2026-05-26 12:30:26'),(16,305,'Call','Connected','dfgdg',3,'2026-05-26 12:30:37'),(17,305,'WhatsApp','Sent','rerter',3,'2026-05-26 12:30:42'),(18,305,'Note','Connected','ertert',3,'2026-05-26 12:30:46'),(19,305,'Note','Connected','retert',3,'2026-05-26 12:30:51'),(20,305,'Note','Connected','ertert',3,'2026-05-26 12:30:56'),(21,305,'Call','Connected','asdsad',3,'2026-05-26 12:32:39'),(22,305,'WhatsApp','Sent','dsadas',3,'2026-05-26 12:32:43'),(23,305,'Call','Connected','dasdsa',3,'2026-05-26 12:33:52'),(24,305,'WhatsApp','Sent','dsadsa',3,'2026-05-26 12:33:55'),(25,304,'Call','Connected','dsfsd',3,'2026-05-26 12:36:38'),(26,304,'WhatsApp','Sent','sdfsdf',3,'2026-05-26 12:36:42'),(27,304,'Note','Connected','sdfsdf',3,'2026-05-26 12:36:45'),(28,303,'Call','Connected','sadsa',3,'2026-05-26 12:44:40');
/*!40000 ALTER TABLE `lead_interactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_sources`
--

DROP TABLE IF EXISTS `lead_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_sources` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_sources`
--

LOCK TABLES `lead_sources` WRITE;
/*!40000 ALTER TABLE `lead_sources` DISABLE KEYS */;
INSERT INTO `lead_sources` VALUES (1,'WhatsApp',1,'2026-04-11 21:41:44'),(2,'Phone Call',1,'2026-04-11 21:41:44'),(3,'Walk-in',1,'2026-04-11 21:41:44'),(4,'Website Inquiry',1,'2026-04-11 21:41:44'),(5,'Referral',1,'2026-04-11 21:41:44'),(6,'Social Media',1,'2026-04-11 21:41:44'),(7,'Meta Ads',1,'2026-04-11 21:41:44'),(8,'Google Ads',1,'2026-04-11 21:41:44'),(9,'Bulk Import',1,'2026-04-11 21:41:44'),(10,'Unknown',1,'2026-04-11 21:41:44');
/*!40000 ALTER TABLE `lead_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_status_history`
--

DROP TABLE IF EXISTS `lead_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_status_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_id` bigint NOT NULL,
  `old_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `changed_by` bigint DEFAULT NULL,
  `changed_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_id` (`lead_id`),
  KEY `idx_changed_at` (`changed_at`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_status_history`
--

LOCK TABLES `lead_status_history` WRITE;
/*!40000 ALTER TABLE `lead_status_history` DISABLE KEYS */;
INSERT INTO `lead_status_history` VALUES (1,264,'New',NULL,3,'2026-05-23 22:07:13'),(2,268,'New',NULL,3,'2026-05-23 22:07:13'),(3,264,'New',NULL,3,'2026-05-23 22:07:15'),(4,268,'New',NULL,3,'2026-05-23 22:07:15'),(5,264,'New',NULL,3,'2026-05-23 22:12:16'),(6,268,'New',NULL,3,'2026-05-23 22:12:16'),(7,264,'New',NULL,3,'2026-05-23 22:12:17'),(8,268,'New',NULL,3,'2026-05-23 22:12:17'),(9,263,'New',NULL,3,'2026-05-23 22:21:34'),(10,262,'New',NULL,3,'2026-05-23 22:21:34'),(11,262,'New',NULL,3,'2026-05-23 22:21:34'),(12,263,'New',NULL,3,'2026-05-23 22:21:34'),(13,262,'New',NULL,3,'2026-05-23 22:32:12'),(14,263,'New',NULL,3,'2026-05-23 22:32:12'),(15,246,'New','New',3,'2026-05-23 22:46:16'),(16,245,'New','New',3,'2026-05-23 22:46:16'),(17,245,'New','New',3,'2026-05-23 22:46:41'),(18,246,'New','New',3,'2026-05-23 22:46:41'),(19,242,'New','New',3,'2026-05-23 22:47:05'),(20,244,'New','New',3,'2026-05-23 22:47:05'),(21,242,'New','New',3,'2026-05-23 22:47:20'),(22,244,'New','New',3,'2026-05-23 22:47:20'),(23,238,'New','New',3,'2026-05-23 22:47:47'),(24,239,'New','New',3,'2026-05-23 22:47:47'),(25,245,'New','New',3,'2026-05-23 22:48:14'),(26,246,'New','New',3,'2026-05-23 22:48:14'),(27,245,'New','New',3,'2026-05-23 22:48:22'),(28,246,'New','New',3,'2026-05-23 22:48:22'),(29,245,'New','New',3,'2026-05-23 22:48:32'),(30,246,'New','New',3,'2026-05-23 22:48:32'),(31,245,'New','New',3,'2026-05-23 22:48:41'),(32,246,'New','New',3,'2026-05-23 22:48:41'),(33,245,'New','New',3,'2026-05-23 22:49:40'),(34,246,'New','New',3,'2026-05-23 22:49:40'),(35,245,'New','New',3,'2026-05-23 22:51:14'),(36,246,'New','New',3,'2026-05-23 22:51:14'),(37,245,'New','New',3,'2026-05-24 08:16:23'),(38,246,'New','New',3,'2026-05-24 08:16:23'),(39,245,'New','Contacted',3,'2026-05-24 08:17:01'),(40,246,'New','Contacted',3,'2026-05-24 08:17:01'),(41,242,'New','New',3,'2026-05-24 09:37:11'),(42,244,'New','New',3,'2026-05-24 09:37:11'),(43,234,'New','Follow-up',3,'2026-05-25 17:39:21'),(44,233,'New','Follow-up',3,'2026-05-25 17:45:08'),(45,293,'New','Follow-up',3,'2026-05-25 21:25:23'),(46,304,'New','Follow-up',3,'2026-05-26 09:21:01'),(47,305,'New','Follow-up',3,'2026-05-26 16:58:24'),(48,222,'Follow-up','Converted',3,'2026-05-26 17:26:06');
/*!40000 ALTER TABLE `lead_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_source_id` bigint DEFAULT NULL,
  `lead_source_detail` varchar(255) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `parent_name` varchar(255) DEFAULT NULL,
  `parent_contact` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `whatsapp_same` tinyint(1) DEFAULT '1',
  `alternate_phone` varchar(20) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` enum('Male','Female','Other','Prefer not to say') DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `year_of_passing` year DEFAULT NULL,
  `city` varchar(80) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'India',
  `area_locality` varchar(120) DEFAULT NULL,
  `counselor_remarks` text,
  `interested_course` varchar(255) DEFAULT NULL,
  `urgency` varchar(50) DEFAULT 'Normal',
  `referred_by_name` varchar(100) DEFAULT NULL,
  `referred_by_phone` varchar(15) DEFAULT NULL,
  `referred_by_type` enum('Doctor','Patient','Friend/Family','Staff','Other') DEFAULT NULL,
  `lead_status` varchar(50) DEFAULT 'New',
  `is_archived` tinyint(1) DEFAULT '0',
  `lead_quality` enum('hot','warm','cold','unverified','low') DEFAULT 'unverified',
  `next_follow_up_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `first_contacted_at` datetime DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `converted_at` datetime DEFAULT NULL,
  `assigned_user_id` int DEFAULT NULL,
  `lead_uid` varchar(15) DEFAULT NULL,
  `source_project` varchar(100) DEFAULT NULL,
  `assignment_mode` varchar(50) DEFAULT 'manual',
  `assignment_reason` varchar(255) DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT NULL,
  `lost_at` datetime DEFAULT NULL,
  `status_updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `last_interaction_at` datetime DEFAULT NULL,
  `lead_score` int DEFAULT '0',
  `assigned_to` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `lead_uid` (`lead_uid`),
  KEY `fk_lead_source` (`lead_source_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_followup` (`next_follow_up_date`),
  KEY `idx_full_name` (`full_name`),
  KEY `idx_assigned_user` (`assigned_user_id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_status` (`lead_status`),
  KEY `idx_leads_status` (`lead_status`),
  KEY `idx_leads_assigned` (`assigned_user_id`),
  KEY `idx_converted_at` (`converted_at`),
  KEY `idx_deleted_at` (`deleted_at`),
  KEY `idx_status_updated` (`status_updated_at`),
  KEY `idx_last_interaction` (`last_interaction_at`),
  KEY `idx_user_leads` (`assigned_to`)
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES (4,1,NULL,'Shaji',NULL,NULL,'9999999999',1,NULL,'test@gmail.com',NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,'Normal',NULL,NULL,NULL,'Interested',0,'unverified',NULL,'2026-03-23 11:42:42',NULL,NULL,'2026-05-14 11:01:27',NULL,6,'L26-0004',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(7,1,NULL,'ytyu',NULL,NULL,'6238370278',0,NULL,'webgyorc@gmail.com',NULL,NULL,NULL,NULL,'calicut','India','Kokkala',NULL,NULL,'Normal',NULL,NULL,NULL,'Not Interested',0,'unverified',NULL,'2026-03-23 13:22:38',NULL,NULL,'2026-05-14 11:01:27',NULL,6,'L26-0007',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(8,1,NULL,'Suresh Kumar',NULL,NULL,'9995887744',0,NULL,NULL,52,'Male',NULL,NULL,'Thrissur','India','East Fort',NULL,'Dental implants','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-03-23 13:22:38',NULL,NULL,'2026-05-14 11:01:27',NULL,6,'L26-0008',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(11,1,NULL,'John Doe',NULL,NULL,'9876543210',1,NULL,'webgtorc@gmail.com',34,'Male','MBA',1980,'calicut','India',NULL,'drgrt',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-03-23 19:59:30',NULL,1,'2026-05-14 11:01:27','2026-05-12 23:14:01',6,'L26-0011',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(20,1,NULL,'Sambath',NULL,NULL,'6238370215',0,NULL,'web4orc@gmail.com',34,'Male','MBA',1989,'calicut','India',NULL,'erer','','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-03-23 20:14:03','2026-05-05 23:32:02',1,'2026-05-23 20:30:48',NULL,6,'L26-0020',NULL,'manual',NULL,NULL,NULL,'2026-05-23 20:30:48','2026-05-23 20:30:48',NULL,0,NULL),(26,1,NULL,'ytrty',NULL,NULL,'62382270210',0,NULL,'we5gyorc@gmail.com',44,'Male','MBA',1980,'calicut','India',NULL,'dsfere','Web Development','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-03-23 20:20:23',NULL,1,'2026-05-14 11:01:27',NULL,6,'L26-0026',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(29,1,NULL,'raman',NULL,NULL,'6789876756',1,NULL,'web3orc@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'rreter','Graphic Design','Normal',NULL,NULL,NULL,'Interested',0,'unverified',NULL,'2026-03-25 15:35:07',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-0029',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(31,1,NULL,'Muthu',NULL,NULL,'6238370219',0,NULL,'webgryorc@gmail.com',34,NULL,'MBA',1980,'calicut','India',NULL,'ggggczczxc','Web Development','Normal',NULL,NULL,NULL,'Not Interested',0,'unverified',NULL,'2026-03-25 16:03:39','2026-05-03 11:16:42',3,'2026-05-14 11:01:27',NULL,6,'L26-0031',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(42,2,NULL,'REEL','mukundan','6787655389','6238370710',1,NULL,'webg7rc@gmail.com',55,'Male','MBA',NULL,'calicut','India',NULL,'ertterttyydr','','Normal',NULL,NULL,NULL,'Interested',0,'unverified',NULL,'2026-03-26 14:12:31',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-0042',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(54,1,NULL,'Hiba Fathimavdfdfdf',NULL,NULL,'9048100208',1,NULL,'webgyfrc@gmail.com',23,'Female','MBA',1980,'calicut','India',NULL,'30 Apr: Called - Not Reachable.',NULL,'Normal',NULL,NULL,NULL,'Not Interested',0,'unverified',NULL,'2026-03-26 16:19:04',NULL,NULL,'2026-05-14 11:01:27',NULL,7,'L26-0054',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(55,3,NULL,'Abhinav P',NULL,NULL,'9048100209',1,NULL,'webgforc@gmail.com',23,'Male','MBA',1980,'calicut','India',NULL,'sdfsdfd','Web Development','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-03-26 16:19:04',NULL,NULL,'2026-05-14 11:01:27',NULL,6,'L26-0055',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(60,4,NULL,'Pooja Menon',NULL,NULL,'9048100214',1,NULL,'webgycrc@gmail.com',23,'Female','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-03-26 16:19:04',NULL,NULL,'2026-05-14 11:01:27','2026-05-12 23:14:34',1,'L26-0060',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(61,2,NULL,'Irfan Khan',NULL,NULL,'9048100215',1,NULL,'webgforc@gmail.com',22,'Male','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-03-26 16:19:04',NULL,NULL,'2026-05-14 11:01:27','2026-05-12 23:14:40',1,'L26-0061',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(63,3,NULL,'Kiran Dev',NULL,NULL,'9048100217',1,NULL,'webgrorc@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,NULL,'Web Development','Normal',NULL,NULL,NULL,'Not Interested',0,'unverified',NULL,'2026-03-26 16:19:04',NULL,NULL,'2026-05-14 11:01:27',NULL,1,'L26-0063',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(66,4,NULL,'Devika B',NULL,NULL,'9048100220',1,NULL,'webgydrc@gmail.com',32,'Male','MBA',1980,'calicut','India',NULL,NULL,'Digital Marketing','Normal',NULL,NULL,NULL,'Not Interested',0,'unverified',NULL,'2026-03-26 16:19:04',NULL,NULL,'2026-05-14 11:01:27',NULL,1,'L26-0066',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(68,1,NULL,'Aparna Dassdsdsa',NULL,NULL,'9048100222',1,NULL,'webg14rc@gmail.com',14,NULL,'MBA14',1980,'calicut','India',NULL,'30 Apr: Feedback - Budget Issue. \ndfsdfsdsdf','Flutter App Development','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-03-26 16:40:56',NULL,NULL,'2026-05-14 11:01:27',NULL,1,'L26-0068',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(70,7,NULL,'Fidha Parveen',NULL,NULL,'9048100224',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,'Digital Marketing','Normal',NULL,NULL,NULL,'Interested',0,'unverified',NULL,'2026-03-26 16:40:56',NULL,NULL,'2026-05-14 11:01:27',NULL,1,'L26-0070',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(75,2,NULL,'Vishnu Vardhan','ewwer','6787656349','9048100229',1,NULL,NULL,0,NULL,NULL,0000,NULL,'India',NULL,'12 May: Called - Connected. \nhfdhff',NULL,'Normal',NULL,NULL,NULL,'Contacted',0,'unverified',NULL,'2026-03-26 16:40:56','2026-05-12 08:57:21',NULL,'2026-05-14 11:01:27',NULL,1,'L26-0075',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(76,1,NULL,'Gopika G',NULL,NULL,'9048100230',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,'Digital Marketing Masterclassd','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-03-26 16:40:56',NULL,NULL,'2026-05-14 11:01:27',NULL,1,'L26-0076',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(77,2,NULL,'Sreeja Pillai',NULL,NULL,'9447001235',1,NULL,'sreeja@example.com',NULL,NULL,NULL,NULL,'Kollam','India',NULL,'12 May: Called - Connected.\nShaji mukundan+ragini+rajeevam',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-03-27 02:14:23',NULL,1,'2026-05-14 11:01:27','2026-05-12 23:14:49',1,'L26-0077',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(81,1,NULL,'Anil KumarD','ghjhgj','67876563779','9847830101',1,NULL,'anild@test.com',43,NULL,'MBA',1980,'Calicut','India',NULL,'12 May: Called - Connected. \nretertret','Digital Marketing Masterclassd','Normal',NULL,NULL,NULL,'Contacted',0,'hot',NULL,'2026-03-28 19:11:29','2026-05-12 08:57:10',3,'2026-05-14 11:01:27',NULL,1,'L26-0081',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(87,10,NULL,'Abhijith K.',NULL,NULL,'9847012305',1,NULL,'abhi.k@email.com',0,NULL,NULL,NULL,'Palakkad','India',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-03-29 21:59:44',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:14:55',1,'L26-0087',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(94,10,NULL,'Sneha Kapoor','rtert','6787653389','9847223344',1,NULL,'sneha.k@test.com',23,NULL,'MBA',1990,'Kochi','India',NULL,'ertre','Digital Marketing Masterclassd','Normal',NULL,NULL,NULL,'Converted',0,'hot',NULL,'2026-03-29 22:02:46',NULL,3,'2026-05-14 11:01:27','2026-05-12 22:39:22',1,'L26-0094',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(99,1,NULL,'Vishal Raj','mrrtrt','6787652389','9847778899',1,NULL,'vishal.r@test.com',232,NULL,'MBA',1980,'Kannur','India',NULL,'weewrsdfsdf','MERN Stack Development','Normal',NULL,NULL,NULL,'Follow-up',0,'cold','2026-05-06','2026-03-29 22:02:46','2026-05-06 15:08:55',3,'2026-05-14 11:01:27',NULL,6,'L26-0099',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(111,10,NULL,'Navya Nair',NULL,NULL,'9847229933',1,NULL,'navya.n@test.com',NULL,NULL,NULL,NULL,'Calicut','India',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-03-29 22:02:46',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:15:04',1,'L26-0111',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(120,5,NULL,'santhi','mukundan','6784787389','8765787645',1,NULL,'santhi@webgyor.com',22,'Female','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.\nsdffdsfsfsdf',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-04-11 17:46:57',NULL,6,'2026-05-14 11:01:27','2026-05-12 23:15:09',1,'L26-0120',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(121,1,NULL,'shyam','mukundan','67876655389','6565677889',0,NULL,'shya@webgyor.com',22,'Male','MBA',1980,'calicut','India',NULL,'30 Apr: Called - Connected. \n14 Apr: Feedback - Budget Issue.\ngfddfgdf','MERN Stack Development','Normal',NULL,NULL,NULL,'Follow-up',0,'unverified','2026-05-15','2026-04-11 18:00:19','2026-04-30 10:59:28',3,'2026-05-14 11:01:27',NULL,1,'L26-0121',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(122,3,NULL,'sam','mukundan','6787567389','98766456484',1,NULL,'webg3rc@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.\nddfdfgdfg',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-04-11 18:07:34',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:15:14',1,'L26-0122',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(123,9,NULL,'Suni Kumar',NULL,NULL,'9847020101',1,NULL,'sunil@test.com',0,NULL,NULL,NULL,'Kochi','India',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-04-12 09:25:06',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:15:18',6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(126,9,NULL,'Paneer Kumar',NULL,NULL,'9847027101',1,NULL,'paneer@test.com',0,NULL,NULL,NULL,'Kochi','India',NULL,'12 May: Called - Connected.\n25 Apr: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-04-12 09:25:06',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:15:22',6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(134,2,NULL,'keethi','Suresh','1990','3456765435',1,NULL,'email41@gmail.com',234,'Female','Degree',1980,'Vadakara','India',NULL,'12 May: Called - Connected.\nEnthoro mahanu',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-04-19 15:56:36',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:15:28',7,'L26-0134',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(135,2,NULL,'Kancha','mukundan','6787655389','7658764567',1,NULL,'email33@gmail.com',22,'Male','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.\n19 Apr: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-04-19 16:04:38',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:15:32',7,'L26-0135',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(151,9,NULL,'Kapi','mukundan','6787667377','6787678765',1,NULL,'emil4@gmail.com',22,'Male','MBA',1980,'calicut','India',NULL,'testing joined','Flutter App Development','Normal',NULL,NULL,NULL,'Converted',0,'warm',NULL,'2026-04-28 17:22:27',NULL,3,'2026-05-14 11:01:27','2026-05-12 22:40:14',7,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(152,1,NULL,'Ramanujan','mukundan','6787667366','6789876567',1,NULL,'sample1@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'testing','IAS COACHING','Normal',NULL,NULL,NULL,'Not Interested',0,'unverified',NULL,'2026-04-28 21:49:06',NULL,3,'2026-05-14 11:01:27',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(153,1,NULL,'Koppu','mukundan','6787653388','7687980989',1,NULL,'email3@gmail.com',22,'Male','MBA',1980,'calicut','India',NULL,'testingfgdfg','IAS COACHING','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-04-29 02:07:26',NULL,3,'2026-05-14 11:01:27',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(159,1,NULL,'SUma','mukundan','6787667888','8886756765',0,NULL,'email321@gmail.com',22,'Female','MBA',1980,'calicut','India',NULL,'testinghgfhgfbvvfhfghdasdasd','IAS COACHING','Normal',NULL,NULL,NULL,'Not Interested',0,'warm',NULL,'2026-04-30 06:36:12','2026-05-01 12:36:49',3,'2026-05-14 11:01:27',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(160,9,NULL,'saravan','mukundan','6787667777','6787987856',0,NULL,'email90@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.\ntstingfsdfsdfzxczxczxc',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-05-02 04:27:41','2026-05-02 09:57:53',3,'2026-05-14 11:01:27','2026-05-12 23:15:37',6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(161,8,NULL,'Newone','mukundan','7876767878','6787987878',0,NULL,'email44@gmail.com',22,'Female','MBA',1980,'calicut','India',NULL,'testing','IAS COACHING','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-05-02 14:20:38','2026-05-03 11:25:34',3,'2026-05-14 11:01:27',NULL,7,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(162,8,NULL,'ramu','mukundan','6787667366','6789878987',0,NULL,'email11@gmail.com',22,'Male','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.\ntestingbvnvbngfhfg','Flutter App Development','Normal',NULL,NULL,NULL,'Converted',0,'hot',NULL,'2026-05-03 05:38:33','2026-05-03 11:14:24',3,'2026-05-14 11:01:27','2026-05-12 23:15:45',1,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(166,1,NULL,'Rani','mukundan','6787667300','8767567800',0,NULL,'email223@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'testingsasdasdsadfdfxzxcnm,nm','Flutter App Development','Normal',NULL,NULL,NULL,'Not Interested',0,'warm',NULL,'2026-05-03 06:01:05','2026-05-04 09:22:39',3,'2026-05-14 11:01:27',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(168,9,NULL,'Mani','mukundan','6787667555','8987676562',0,NULL,'email222@gmail.com',NULL,NULL,'MBA',1980,'calicut','India',NULL,'testingddsfdfd','IAS COACHING','Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-05-03 06:38:15','2026-05-03 12:08:30',3,'2026-05-14 11:01:27',NULL,1,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(170,8,NULL,'Santhi','mukundan','6787667666','8798768756',0,NULL,'email98@gmial.com',44,'Male','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.\ntesting donefgfdasdsadfghfghvcbvcjghjghcvcvhgjghjghj','IAS COACHING','Normal',NULL,NULL,NULL,'Converted',0,'hot',NULL,'2026-05-04 03:59:48','2026-05-04 09:34:09',3,'2026-05-14 11:01:27','2026-05-12 23:15:50',6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(175,8,NULL,'Aswathi Kumari1','mukundan','6787667000','6798756787',1,NULL,'email222@gmail.com',23,'Female','MBA',1980,'calicut','India',NULL,'testing','IAS COACHING','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-06 09:44:21',NULL,3,'2026-05-14 11:01:27',NULL,1,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(176,1,NULL,'Renjith Kumar','mukundan','6787678004','8987687989',1,NULL,'email45@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'testing','IAS COACHING','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 07:54:44',NULL,3,'2026-05-14 11:01:27',NULL,1,NULL,NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:43:57',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(177,1,NULL,'Ragin Raj','mukundan','6787678980','6787567879',1,NULL,'email123@gmail.com',24,'Female','MBA',1980,'calicut','India',NULL,'testing','Flutter App Development','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 07:55:58',NULL,3,'2026-05-14 11:01:27',NULL,2,NULL,NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:43:59',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(178,9,NULL,'Rahul Das',NULL,NULL,'9847012301',1,NULL,'rahul.das@email.com',NULL,NULL,NULL,NULL,'Calicut','India',NULL,NULL,'Python Full Stack','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:16',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-9603',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:01',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(179,9,NULL,'Anjali Nair',NULL,NULL,'9847012302',1,NULL,'anjali.nair@email.com',NULL,NULL,NULL,NULL,'Kochi','India',NULL,NULL,'Data Science','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:16',NULL,3,'2026-05-14 11:01:27',NULL,7,'L26-2135',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:02',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(180,9,NULL,'Mohammed Fayiz',NULL,NULL,'9847012303',1,NULL,'fayiz.m@email.com',NULL,NULL,NULL,NULL,'Malappuram','India',NULL,NULL,'MERN Stack','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:17',NULL,3,'2026-05-14 11:01:27',NULL,1,'L26-7862',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:04',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(181,9,NULL,'Sneha George',NULL,NULL,'9847012304',1,NULL,'sneha.g@email.com',NULL,NULL,NULL,NULL,'Thrissur','India',NULL,NULL,'UI/UX Design','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:17',NULL,3,'2026-05-14 11:01:27',NULL,2,'L26-4909',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:06',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(182,9,NULL,'Arun Varma',NULL,NULL,'9847012306',1,NULL,'arun.v@email.com',NULL,NULL,NULL,NULL,'Kozhikode','India',NULL,NULL,'Cyber Security','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:18',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-8960',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:08',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(183,9,NULL,'Meera Joseph',NULL,NULL,'9847012307',1,NULL,'meera.j@email.com',NULL,NULL,NULL,NULL,'Kottayam','India',NULL,NULL,'Software Testing','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:18',NULL,3,'2026-05-14 11:01:27',NULL,7,'L26-2074',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:10',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(184,9,NULL,'Saritha S.',NULL,NULL,'9847012308',1,NULL,'saritha.s@email.com',NULL,NULL,NULL,NULL,'Kannur','India',NULL,NULL,'Python Full Stack','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:19',NULL,3,'2026-05-14 11:01:27',NULL,1,'L26-9488',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:12',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(185,9,NULL,'Vivek Menon',NULL,NULL,'9847012309',1,NULL,'vivek.m@email.com',NULL,NULL,NULL,NULL,'Trivandrum','India',NULL,NULL,'Data Science','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:19',NULL,3,'2026-05-14 11:01:27',NULL,2,'L26-4223',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:14',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(186,9,NULL,'Deepak P.',NULL,NULL,'9847012310',1,NULL,'deepak.p@email.com',NULL,NULL,NULL,NULL,'Calicut','India',NULL,NULL,'MERN Stack','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:15:20',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-9649',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:44:15',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(187,9,NULL,'Abhijith K',NULL,NULL,'9847000111',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,'MERN Stack','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:58:34',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-6347',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:58:35',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(188,9,NULL,'Riya Sharma',NULL,NULL,'9847000222',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,'Digital Marketing','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:58:37',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-7761',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:58:37',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(189,9,NULL,'Sandeep Raj',NULL,NULL,'9847000333',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UAE',NULL,NULL,'Python Django','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:58:39',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-4414',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:58:39',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(190,9,NULL,'Anjali Nair',NULL,NULL,'9847000444',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UK',NULL,NULL,'UI/UX Design','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 15:58:41',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-9166',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 15:58:41',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(191,9,NULL,'Ibrahim Khan',NULL,NULL,'9715099988',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UAE',NULL,NULL,'Digital Marketing','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 16:14:58',NULL,3,'2026-05-14 11:01:27',NULL,7,'L26-7658',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 16:14:58',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(192,9,NULL,'John Doe',NULL,NULL,'4477112233',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UK',NULL,NULL,'UI/UX Design','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 16:15:00',NULL,3,'2026-05-14 11:01:27',NULL,1,'L26-3281',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 16:15:00',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(193,9,NULL,'Mark Smith',NULL,NULL,'1604555123',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Canada',NULL,NULL,'MERN Stack','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 16:15:01',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-2521',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 16:15:02',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(194,9,NULL,'Hans Weber',NULL,NULL,'4915123456',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Germany',NULL,NULL,'Python Django','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 16:15:03',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-1198',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 16:15:04',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(195,9,NULL,'Alice Wong',NULL,NULL,'6129876543',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Australia',NULL,NULL,'Flutter Development','Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-07 16:15:05',NULL,3,'2026-05-14 11:01:27',NULL,7,'L26-3832',NULL,'round_robin','Automated assignment via round_robin','2026-05-07 16:15:06',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(197,1,'Auto-captured from website','Arjun WebGyor','mukundan','6787667390','9999988888',1,NULL,'arjun@webgyor.com',NULL,NULL,'MBA',1980,'calicut','India',NULL,'werwer','IAS COACHING','Normal',NULL,NULL,NULL,'Follow-up',0,'unverified','2026-05-21','2026-05-08 08:38:46','2026-05-11 16:06:51',NULL,'2026-05-14 11:01:27',NULL,1,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(201,4,NULL,'Naveewn Kumar',NULL,NULL,'6238370555',1,NULL,'webgwec@gmail.com',NULL,NULL,NULL,NULL,NULL,'India',NULL,'System Capture | Source ID: 4 | Project: sakshi-test-project',NULL,'Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-10 16:55:05',NULL,NULL,'2026-05-14 11:01:27',NULL,6,'L-2026-505c4346','sakshi-test-project','manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(203,7,NULL,'Rahul Sharma',NULL,NULL,'9847000999',1,NULL,'rahul.webgyor@test.com',NULL,NULL,NULL,NULL,NULL,'India',NULL,'System Capture | Source ID: 1 | Project: sakshi_chat',NULL,'Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-10 17:14:25',NULL,NULL,'2026-05-14 11:01:27',NULL,1,'L26-1538','sakshi_chat','manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(204,6,NULL,'Praveen Kumar','mukundan','6787666756','6238370765',1,NULL,'webgerec@gmail.com',NULL,NULL,'MBA',1980,'calicut','India',NULL,'13 May: Called - Connected. \nSystem Capture | Source ID: 4 | Project: sakshi-test-project','NEET COURSE TWO','Normal',NULL,NULL,NULL,'Contacted',0,'warm',NULL,'2026-05-10 17:14:45','2026-05-13 03:19:04',NULL,'2026-05-14 11:01:27',NULL,7,'L26-6301','sakshi-test-project','manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(205,7,NULL,'Kamalesh Kumar','mukundan','6787656789','6238370123',1,NULL,'webyterec@gmail.com',43,'Male','MBA',1990,'calicut','India',NULL,'13 May: Called - Connected. \nSystem Capture | Source ID: 4 | Project: sakshi-test-project','NEET Crash Course 2027','Normal',NULL,NULL,NULL,'Contacted',0,'hot',NULL,'2026-05-10 17:19:57','2026-05-13 03:32:12',NULL,'2026-05-14 11:01:27',NULL,7,'L26-6846','sakshi-test-project','manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(208,4,NULL,'Lekshmi Nivas','mukundan','6787667222','6238370434',1,NULL,'admin@aurafaeshion.com',NULL,NULL,'MBA',1980,'calicut','India',NULL,'System Capture | Source ID: 4 | Project: sakshi-test-project','IAS COACHING','Normal',NULL,NULL,NULL,'Follow-up',0,'hot','2026-05-13','2026-05-11 11:13:03','2026-05-12 14:05:47',NULL,'2026-05-14 11:01:27',NULL,1,'L26-9545','sakshi-test-project','manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(219,1,NULL,'Prabhu','mukundan','6787668888','6578764567',1,NULL,'emailpra@gmail.com',23,'Male','MBA',1981,'calicut','India',NULL,'12 May: Called - Connected.\ntesging','Flutter App Development','Normal',NULL,NULL,NULL,'Interested',0,'hot',NULL,'2026-05-12 12:49:23','2026-05-12 14:03:41',3,'2026-05-14 11:01:27',NULL,7,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(220,1,NULL,'sharma','mukundan','6787688888','6768787898',1,NULL,'emailll@gmail.com',33,'Male','MBA',1989,'calicut','India',NULL,'12 May: Called - Connected.\ntestingbvnvbn','Digital Marketing Masterclassd','Normal',NULL,NULL,NULL,'Interested',0,'hot',NULL,'2026-05-12 13:57:58','2026-05-12 14:15:04',3,'2026-05-14 11:01:27',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(221,2,NULL,'Final test','mukundan','6787667778','6787985768',1,NULL,'email@gmail.com',23,'Other','MBA',1980,'calicut','India',NULL,'12 May: Called - Connected.\ntesting','Flutter App Development','Normal',NULL,NULL,NULL,'Contacted',0,'hot',NULL,'2026-05-12 15:47:34','2026-05-12 15:47:48',3,'2026-05-14 11:01:27',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(222,6,NULL,'Aditya Verma','mukundan','6787667123','9847012345',1,NULL,'webgyorcwe@gmail.com',NULL,NULL,'MBA',1990,'calicut','India',NULL,'12 May: Called - Connected. inter','MERN Stack Development','Normal',NULL,NULL,NULL,'Converted',0,'hot',NULL,'2026-05-12 19:46:27','2026-05-12 23:01:19',3,'2026-05-26 17:26:07','2026-05-26 17:26:07',6,'L26-1483',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-26 17:26:07',NULL,NULL,0,NULL),(223,6,NULL,'Mohammad Al-Saud','mukundan','6787667090','6501234567',1,NULL,'webgyorc@gmail.com',NULL,NULL,'MBA',0000,'calicut','Saudi Arabia',NULL,'12 May: Called - Connected. WON','MERN Stack Development','Normal',NULL,NULL,NULL,'Follow-up',0,'hot','2026-05-28','2026-05-12 19:46:27','2026-05-12 23:06:19',3,'2026-05-26 17:25:43','2026-05-12 22:42:01',6,'L26-3951',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(224,9,NULL,'Sreelakshmi S.',NULL,NULL,'9946055443',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Lost',0,'unverified',NULL,'2026-05-12 19:46:27',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-4257',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27','2026-05-13 03:08:50','2026-05-14 11:01:27',NULL,NULL,0,NULL),(225,9,NULL,'Oliver Bennett',NULL,NULL,'7700900123',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UK',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Not Interested',0,'unverified',NULL,'2026-05-12 19:46:27',NULL,3,'2026-05-14 11:01:27',NULL,7,'L26-7601',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(226,9,NULL,'Mariam Al-Hashemi',NULL,NULL,'1509876543',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UAE',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Interested',0,'unverified',NULL,'2026-05-12 19:46:27',NULL,3,'2026-05-14 11:01:27',NULL,6,'L26-4018',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(227,9,NULL,'Rohit Krishnan','mukundan','678766667','9447088992',1,NULL,'webgyorc@gmail.com',NULL,NULL,'MBA',0000,'calicut','India',NULL,'12 May: Called - Connected.','Flutter App Development','Normal',NULL,NULL,NULL,'Converted',0,'hot',NULL,'2026-05-12 19:46:27',NULL,3,'2026-05-14 11:01:27','2026-05-12 22:55:03',1,'L26-9712',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(228,2,NULL,'Hassan Qureshi','mukundan','6787667980','6552233445',1,NULL,'webgyoe4c@gmail.com',33,'Female','MBA',1990,'calicut','Saudi Arabia',NULL,'13 May: Called - Connected.','NEET COURSE TWO','Normal',NULL,NULL,NULL,'Contacted',0,'warm',NULL,'2026-05-12 19:46:27','2026-05-13 03:01:17',3,'2026-05-14 11:01:27',NULL,6,'L26-7793',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(229,9,NULL,'Emily Watson',NULL,NULL,'7825123456',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UK',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Converted',0,'unverified',NULL,'2026-05-12 19:46:27',NULL,3,'2026-05-14 11:01:27','2026-05-12 23:02:15',1,'L26-4180',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(230,9,NULL,'Zaid Al-Zahrani',NULL,NULL,'1521122334',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UAE',NULL,'12 May: Called - Connected.',NULL,'Normal',NULL,NULL,NULL,'Follow-up',0,'unverified','2026-05-13','2026-05-12 19:46:27','2026-05-12 23:01:48',3,'2026-05-14 11:01:27',NULL,1,'L26-3471',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(231,9,NULL,'Ananya Nair',NULL,NULL,'9567011223',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,'12 May: Called - Connected.dgdg',NULL,'Normal',NULL,NULL,NULL,'Follow-up',0,'unverified','2026-05-15','2026-05-12 19:46:27','2026-05-12 23:06:34',3,'2026-05-26 17:25:53',NULL,1,'L26-8095',NULL,'round_robin','Automated assignment via round_robin','2026-05-12 14:16:27',NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(232,9,NULL,'sharavanan','mukundan','6787667685','9447088567',1,NULL,'emaiwww@gmail.com',34,'Male','MBA',1990,'calicut','India',NULL,'13 May: Called - Connected.\ntesting','Digital Marketing Masterclassd','Normal',NULL,NULL,NULL,'Converted',0,'hot',NULL,'2026-05-13 03:03:24','2026-05-13 03:03:54',3,'2026-05-14 11:01:27','2026-05-13 09:33:57',1,'L26-9723',NULL,'manual',NULL,NULL,NULL,'2026-05-14 11:01:27',NULL,NULL,0,NULL),(233,NULL,NULL,'Zainab A',NULL,NULL,'9847000030',1,NULL,'zainab@example.com',NULL,NULL,NULL,NULL,'Kochi','India',NULL,'Archive test: Duplicate (Restored from Archive)',NULL,'Normal',NULL,NULL,NULL,'Follow-up',0,'cold','2026-05-27','2026-05-15 01:59:19','2026-05-25 17:45:09',NULL,'2026-05-25 17:45:09',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-25 17:45:09',NULL,NULL,0,NULL),(234,NULL,NULL,'Safa Mariyam','mukundan','6787667666','9048100206',1,NULL,'webcyorc@gmail.com',23,'Male','MBA',1980,'calicut','India',NULL,'contacted (Restored from Archive)\n[CALL] Connected\n[Called] Not Reachable',NULL,'Immediate (pain)',NULL,NULL,NULL,'Follow-up',0,'hot','2026-05-26','2026-05-18 18:57:16','2026-05-25 17:39:22',NULL,'2026-05-25 17:44:46',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-25 17:39:22',NULL,NULL,0,NULL),(235,NULL,NULL,'Gautham Raj',NULL,NULL,'9048100207',1,NULL,'webggorc@gmail.com',NULL,NULL,NULL,NULL,'calicut','India',NULL,NULL,'Web Development','Normal',NULL,NULL,NULL,'Cold Storage',1,'unverified',NULL,'2026-05-18 19:04:26',NULL,NULL,'2026-05-25 08:25:41',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-25 08:25:41','2026-05-25 08:25:41',NULL,0,NULL),(237,NULL,NULL,'Yamuna P',NULL,NULL,'9847000029',1,NULL,'yamuna@example.com',NULL,NULL,NULL,NULL,'Palakkad','India',NULL,'Location very far (Restored from Archive)','UI/UX Design','Normal',NULL,NULL,NULL,'Cold Storage',1,'',NULL,'2026-05-18 19:08:33',NULL,NULL,'2026-05-24 15:43:19',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 15:43:19','2026-05-24 15:43:19',NULL,0,NULL),(238,NULL,NULL,'Vineeth S',NULL,NULL,'9847000026',1,NULL,'vineeth@example.com',NULL,NULL,NULL,NULL,'Ernakulam','India',NULL,'Waitlist expired (Restored from Archive)','MERN Stack','Normal',NULL,NULL,NULL,'Cold Storage',1,'cold',NULL,'2026-05-18 19:10:35',NULL,NULL,'2026-05-24 15:33:56',NULL,1,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 15:33:56','2026-05-24 15:33:56',NULL,0,1),(239,NULL,NULL,'Waseem J',NULL,NULL,'9847000027',1,NULL,'waseem@example.com',NULL,NULL,NULL,NULL,'Malappuram','India',NULL,'Moved abroad (Restored from Archive)','Python Full Stack','Normal',NULL,NULL,NULL,'Cold Storage',1,'cold',NULL,'2026-05-18 19:14:56',NULL,NULL,'2026-05-24 15:28:43',NULL,1,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 15:28:43','2026-05-24 15:28:43',NULL,0,1),(242,NULL,NULL,'Anagha Nair',NULL,NULL,'9048100204',1,NULL,'webgycc@gmail.com',NULL,NULL,NULL,NULL,'calicut','India',NULL,'contacted (Restored from Archive)','Web Development','Normal',NULL,NULL,NULL,'Cold Storage',1,'unverified',NULL,'2026-05-19 07:56:56',NULL,NULL,'2026-05-24 15:23:00',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 15:23:00','2026-05-24 15:23:00',NULL,0,6),(243,2,NULL,'Kannur Test Student',NULL,NULL,'+919999999902',1,NULL,'student.knr@test.com',NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,'Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-19 16:41:53',NULL,NULL,'2026-05-24 08:18:09',NULL,21,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 08:18:09','2026-05-24 08:18:09',NULL,0,NULL),(244,2,NULL,'Malappuram Test Applicant',NULL,NULL,'+919999999903',1,NULL,'applicant.mpm@test.com',NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,'Normal',NULL,NULL,NULL,'Cold Storage',1,'unverified',NULL,'2026-05-19 16:41:53',NULL,NULL,'2026-05-24 15:22:43',NULL,6,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 15:22:43','2026-05-24 15:22:43',NULL,0,6),(251,1,NULL,'Test Lead Malappuram 002',NULL,NULL,'8877665502',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,'Normal',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-21 11:18:14',NULL,NULL,'2026-05-23 20:29:08',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-23 20:29:08','2026-05-23 20:29:08',NULL,0,NULL),(257,1,NULL,'Arjun Malappuram',NULL,NULL,'8891000002',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,'Normal',NULL,NULL,NULL,'New',0,'warm',NULL,'2026-05-21 11:18:35',NULL,NULL,'2026-05-23 19:37:31',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-23 19:37:31','2026-05-23 19:37:31',NULL,0,NULL),(258,1,NULL,'Meera Malappuram',NULL,NULL,'8891000003',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,'Normal',NULL,NULL,NULL,'Follow-up',0,'warm',NULL,'2026-05-21 11:18:35',NULL,NULL,'2026-05-23 19:37:43',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-23 19:37:43','2026-05-23 19:37:43',NULL,0,NULL),(259,1,NULL,'Vipin Malappuram',NULL,NULL,'8891000004',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,'Normal',NULL,NULL,NULL,'Converted',0,'hot',NULL,'2026-05-21 11:18:35',NULL,NULL,'2026-05-23 19:37:23',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-23 19:37:23','2026-05-23 19:37:23',NULL,0,NULL),(269,NULL,NULL,'Usha Uthup',NULL,NULL,'9847000025',1,NULL,'usha@example.com',NULL,NULL,NULL,NULL,'Kochi','India',NULL,'Archive test: Joined elsewhere (Restored from Archive)','Digital Marketing','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2026-05-23 19:32:47',NULL,NULL,'2026-05-23 19:37:52',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-23 19:37:52','2026-05-23 19:37:52',NULL,0,NULL),(270,NULL,NULL,'Tinu Anand',NULL,NULL,'9847000024',1,NULL,'tinu@example.com',NULL,NULL,NULL,NULL,'Kozhikode','India',NULL,'Archive test: Personal (Restored from Archive)','UI/UX Design','Normal',NULL,NULL,NULL,'New',0,'low',NULL,'2026-05-23 19:38:48',NULL,NULL,'2026-05-23 20:25:10',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-23 20:25:10','2026-05-23 20:25:10',NULL,0,NULL),(278,NULL,NULL,'Suresh Gopi',NULL,NULL,'9847000023',1,NULL,'suresh@example.com',NULL,NULL,NULL,NULL,'Trivandrum','India',NULL,'Movie star test lead (Restored from Separate Archive)','Data Science','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2025-04-25 15:00:00',NULL,NULL,'2026-04-25 15:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 13:59:32',NULL,NULL,0,NULL),(279,NULL,NULL,'Roshni K',NULL,NULL,'9847000022',1,NULL,'roshni@example.com',NULL,NULL,NULL,NULL,'Kannur','India',NULL,'Switched off for months (Restored from Separate Archive)','Python Full Stack','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2025-04-20 14:00:00',NULL,NULL,'2026-04-20 14:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 13:59:45',NULL,NULL,0,NULL),(280,NULL,NULL,'Qadir Ali',NULL,NULL,'9847000021',1,NULL,'qadir@example.com',NULL,NULL,NULL,NULL,'Calicut','India',NULL,'Testing vault performance (Restored from Separate Archive)','Digital Marketing','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2025-04-15 13:00:00',NULL,NULL,'2026-04-15 13:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 13:59:45',NULL,NULL,0,NULL),(283,NULL,NULL,'Priya Warrier',NULL,NULL,'9847000020',1,NULL,'priya@example.com',NULL,NULL,NULL,NULL,'Kochi','India',NULL,'Old follow-up pending (Restored from Separate Archive)','MERN Stack','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2025-04-10 12:00:00',NULL,NULL,'2026-04-10 12:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 14:01:14',NULL,NULL,0,NULL),(284,NULL,NULL,'Ouseph P',NULL,NULL,'9847000019',1,NULL,'ouseph@example.com',NULL,NULL,NULL,NULL,'Thrissur','India',NULL,'Archive test: Wrong number (Restored from Separate Archive)','UI/UX Design','Normal',NULL,NULL,NULL,'New',0,'low',NULL,'2025-04-05 11:00:00',NULL,NULL,'2026-04-05 11:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 14:07:15',NULL,NULL,0,NULL),(285,NULL,NULL,'Nandana R',NULL,NULL,'9847000018',1,NULL,'nandana@example.com',NULL,NULL,NULL,NULL,'Pathanamthitta','India',NULL,'Archive test: Joined local (Restored from Separate Archive)','Data Science','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2025-04-01 10:00:00',NULL,NULL,'2026-04-01 10:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 14:09:00',NULL,NULL,0,NULL),(286,NULL,NULL,'Jithin Jose',NULL,NULL,'9847000014',1,NULL,'jithin@example.com',NULL,NULL,NULL,NULL,'Kottayam','India',NULL,'Budget mismatch (Restored from Separate Archive)','UI/UX Design','Normal',NULL,NULL,NULL,'New',0,'',NULL,'2025-03-15 12:15:00',NULL,NULL,'2026-03-15 12:15:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 14:27:18',NULL,NULL,0,NULL),(288,NULL,NULL,'Hridya S',NULL,NULL,'9847000012',1,NULL,'hridya@example.com',NULL,NULL,NULL,NULL,'Idukki','India',NULL,'Archive test: Switching (Restored from Separate Archive)','Python Full Stack','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2025-03-05 10:30:00',NULL,NULL,'2026-03-05 10:30:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 15:18:09',NULL,NULL,0,NULL),(289,NULL,NULL,'Gokul Nath',NULL,NULL,'9847000011',1,NULL,'gokul@example.com',NULL,NULL,NULL,NULL,'Wayanad','India',NULL,'Old database import (Restored from Separate Archive)','Digital Marketing','Normal',NULL,NULL,NULL,'New',0,'cold',NULL,'2025-03-01 09:00:00',NULL,NULL,'2026-03-01 09:00:00',NULL,NULL,NULL,NULL,'manual',NULL,NULL,NULL,'2026-05-24 15:18:09',NULL,NULL,0,NULL),(290,1,NULL,'shaji p.k','mukundan','6787666888','6238370210',1,NULL,'webgyorc@gmail.com',NULL,NULL,'MBA',1980,'calicut','India',NULL,'testing','Flutter App Development','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-25 18:17:29',NULL,3,'2026-05-25 18:17:29',NULL,NULL,'L26-0290',NULL,'manual',NULL,NULL,NULL,'2026-05-25 18:17:29',NULL,NULL,0,NULL),(291,2,NULL,'sharun','mukundan','6787698111','6789876789',1,NULL,'webgyorc@gmail.com',33,'Female','MBA',1980,'calicut','India',NULL,'testing','Digital Marketing Masterclassd','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-25 21:20:29',NULL,3,'2026-05-25 21:20:29',NULL,NULL,'L26-0291',NULL,'manual',NULL,NULL,NULL,'2026-05-25 21:20:29',NULL,NULL,0,NULL),(292,3,NULL,'Shambu','mukundan','6787667003','6789875646',1,NULL,'enao@gmail.com',33,'Male','MBA',NULL,NULL,'India',NULL,'testing','IAS COACHING','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-25 21:21:46',NULL,3,'2026-05-25 21:21:46',NULL,NULL,'L26-0292',NULL,'manual',NULL,NULL,NULL,'2026-05-25 21:21:46',NULL,NULL,0,NULL),(293,4,NULL,'Shajahan','mukundan','6787667112','6567875676',1,NULL,'sdf@gmail.com',45,'Male','MBA',1980,'calicut','India',NULL,'testing',NULL,'Just inquiring',NULL,NULL,NULL,'Follow-up',0,'unverified','2026-05-28','2026-05-25 21:22:58','2026-05-25 21:25:24',3,'2026-05-25 21:25:24',NULL,NULL,'L26-0293',NULL,'manual',NULL,NULL,NULL,'2026-05-25 21:25:24',NULL,NULL,0,NULL),(294,4,NULL,'devu','mukundan','6787667389','6789098764',1,NULL,'sfsd@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'test','Flutter App Development','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-25 21:28:25',NULL,3,'2026-05-25 21:28:25',NULL,NULL,'L26-0294',NULL,'manual',NULL,NULL,NULL,'2026-05-25 21:28:25',NULL,NULL,0,NULL),(295,5,NULL,'kokul','mukundan','6787665434','8765678554',1,NULL,'adsa@gmail.com',33,'Male','MBA',1980,'calicut','India',NULL,'testing','Flutter App Development','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 07:37:40',NULL,3,'2026-05-26 07:37:40',NULL,NULL,'L26-0295',NULL,'manual',NULL,NULL,NULL,'2026-05-26 07:37:40',NULL,NULL,0,NULL),(296,1,NULL,'ramu','mukundan','6787667545','6789876733',1,NULL,'fds@gmail.com',34,'Male','MBA',1980,'calicut','India',NULL,'testing','Flutter App Development','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 07:46:44',NULL,3,'2026-05-26 07:46:44',NULL,NULL,'L26-0296',NULL,'manual',NULL,NULL,NULL,'2026-05-26 07:46:44',NULL,NULL,0,NULL),(297,1,NULL,'rahim','mukundan','6787666545','6787657678',1,NULL,'fdfd@gmail.com',34,'Male','MBA',1980,'calicut','India',NULL,'tedt','Digital Marketing Masterclassd','Immediate (pain)',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 07:59:27',NULL,3,'2026-05-26 07:59:27',NULL,NULL,'L26-0297',NULL,'manual',NULL,NULL,NULL,'2026-05-26 07:59:27',NULL,NULL,0,NULL),(298,6,NULL,'Kuttu','mukundan','67876656453','8767564567',1,NULL,'fdgfd@gmail.com',34,'Female','MBA',1980,'calicut','India',NULL,'test','IAS COACHING','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 08:01:39',NULL,3,'2026-05-26 08:01:39',NULL,NULL,'L26-0298',NULL,'manual',NULL,NULL,NULL,'2026-05-26 08:01:39',NULL,NULL,0,NULL),(299,6,NULL,'Suku','mukundan','6787664323','6789878966',1,NULL,'fgdgfd@gmail.com',34,'Female','MBA',1980,'calicut','India',NULL,'testing','IAS COACHING','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 08:16:42',NULL,3,'2026-05-26 08:16:42',NULL,NULL,'L26-0299',NULL,'manual',NULL,NULL,NULL,'2026-05-26 08:16:42',NULL,NULL,0,NULL),(300,5,NULL,'drs','mukundan','6787667234','6545632345',1,NULL,'dfgd@gmail.com',22,'Female','MBA',1980,'calicut','India',NULL,'testrr','NEET COURSE TWO','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 08:28:46',NULL,3,'2026-05-26 08:28:46',NULL,NULL,'L26-0300',NULL,'manual',NULL,NULL,NULL,'2026-05-26 08:28:46',NULL,NULL,0,NULL),(301,7,NULL,'lalu','mukundan','6787667755','6789878944',1,NULL,'ffdgdf@gmail.com',44,'Female','MBA',1980,'calicut','India',NULL,'test','IAS COACHING','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 08:39:39',NULL,3,'2026-05-26 08:39:39',NULL,NULL,'L26-0301',NULL,'manual',NULL,NULL,NULL,'2026-05-26 08:39:39',NULL,NULL,0,NULL),(302,1,NULL,'shaju','mukundan','6787622223','8767567876',1,NULL,'xvxc@gmail.com',34,'Female','MBA',1980,'calicut','India',NULL,'efew','Digital Marketing Masterclassd','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 08:55:33',NULL,3,'2026-05-26 08:55:33',NULL,NULL,'L26-0302',NULL,'manual',NULL,NULL,NULL,'2026-05-26 08:55:33',NULL,NULL,0,NULL),(303,1,NULL,'sample','mukundan','6787667086','6786563322',1,NULL,'dsfs@gmail.com',32,'Male','MBA',1980,'calicut','India',NULL,'retret','Digital Marketing ','Just inquiring',NULL,NULL,NULL,'New',0,'unverified',NULL,'2026-05-26 09:18:14',NULL,3,'2026-05-26 09:18:14',NULL,NULL,'L26-0303',NULL,'manual',NULL,NULL,NULL,'2026-05-26 09:18:14',NULL,NULL,0,NULL),(304,1,NULL,'Testing','mukundan','6787667389','6788653222',1,NULL,'dsfs@gmail.com',34,'Female','MBA',1980,'calicut','India',NULL,'fsdfsdf',NULL,'Just inquiring',NULL,NULL,NULL,'Follow-up',0,'unverified','2026-05-29','2026-05-26 09:18:47','2026-05-26 09:21:02',3,'2026-05-26 09:21:02',NULL,NULL,'L26-0304',NULL,'manual',NULL,NULL,NULL,'2026-05-26 09:21:02',NULL,NULL,0,NULL),(305,1,NULL,'gopal','mukundan','6787667121','7867565467',1,NULL,'sddf@gmail.com',23,'Male','MBA',1980,'calicut','India',NULL,'test\n[Called] Connected',NULL,'Just inquiring',NULL,NULL,NULL,'Follow-up',0,'unverified','2026-05-26','2026-05-26 16:57:51','2026-05-26 16:58:24',3,'2026-05-26 17:25:37',NULL,NULL,'L26-0305',NULL,'manual',NULL,NULL,NULL,'2026-05-26 16:58:24',NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_logs`
--

DROP TABLE IF EXISTS `login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `device` text,
  `status` varchar(50) DEFAULT NULL,
  `logged_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_logs`
--

LOCK TABLES `login_logs` WRITE;
/*!40000 ALTER TABLE `login_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `group_name` varchar(100) DEFAULT 'General',
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `can_export` tinyint(1) NOT NULL DEFAULT '0',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_feature` (`name`,`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=642 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (4,'Manager','dashboard.view','General',1,0,0,0,0,'2026-05-21 12:10:10'),(5,'Manager','leads.view','General',1,1,1,0,1,'2026-05-20 04:48:26'),(6,'Manager','comms.whatsapp','General',1,1,1,0,1,'2026-05-20 04:48:26'),(7,'Counselor','dashboard.view','General',1,1,1,0,0,'2026-05-20 04:48:26'),(8,'Counselor','leads.view','General',1,1,1,0,0,'2026-05-20 04:48:26'),(9,'Counselor','comms.whatsapp','General',1,1,1,0,0,'2026-05-20 04:48:26'),(10,'Telecaller','dashboard.view','General',1,0,0,0,0,'2026-05-21 12:10:10'),(11,'Telecaller','leads.view','General',1,1,1,0,0,'2026-05-20 09:05:05'),(12,'Telecaller','comms.whatsapp','General',1,1,1,0,0,'2026-05-20 09:05:13'),(179,'Manager','dashboard.stats','General',1,1,1,0,1,'2026-05-20 04:48:26'),(181,'Manager','leads.create','General',1,1,1,0,1,'2026-05-20 04:48:26'),(182,'Manager','leads.edit','General',1,1,1,0,1,'2026-05-20 04:48:26'),(183,'Manager','leads.delete','General',1,1,1,1,1,'2026-05-23 16:49:49'),(185,'Manager','comms.sms','General',1,1,1,0,1,'2026-05-20 04:48:26'),(186,'Manager','comms.email','General',1,1,1,0,1,'2026-05-20 04:48:26'),(187,'Manager','master.branches','General',0,0,0,0,1,'2026-05-20 04:48:26'),(188,'Manager','master.courses','General',1,1,1,0,1,'2026-05-20 04:48:26'),(189,'Manager','master.countries','General',1,1,1,0,1,'2026-05-20 04:48:26'),(190,'Manager','admin.users','General',0,0,0,0,0,'2026-05-20 04:48:26'),(191,'Manager','admin.export','General',1,1,1,0,1,'2026-05-20 04:48:26'),(192,'Manager','admin.settings','General',0,0,0,0,0,'2026-05-20 04:48:26'),(344,'Counselor','dashboard.stats','General',1,1,1,0,0,'2026-05-20 04:48:26'),(346,'Counselor','leads.create','General',1,1,1,0,0,'2026-05-20 04:48:26'),(347,'Counselor','leads.edit','General',1,1,1,0,0,'2026-05-20 04:48:26'),(348,'Counselor','leads.delete','General',1,1,1,1,0,'2026-05-23 16:49:57'),(350,'Counselor','comms.sms','General',1,1,1,0,0,'2026-05-20 04:48:26'),(351,'Counselor','comms.email','General',1,1,1,0,0,'2026-05-20 04:48:26'),(352,'Counselor','master.branches','General',0,0,0,0,0,'2026-05-20 04:48:26'),(353,'Counselor','master.courses','General',1,1,1,0,0,'2026-05-20 04:48:26'),(354,'Counselor','master.countries','General',1,1,1,0,0,'2026-05-20 04:48:26'),(355,'Counselor','admin.users','General',0,0,0,0,0,'2026-05-20 04:48:26'),(356,'Counselor','admin.export','General',1,1,1,0,0,'2026-05-20 04:48:26'),(357,'Counselor','admin.settings','General',0,0,0,0,0,'2026-05-20 04:48:26'),(404,'Telecaller','dashboard.stats','General',1,1,1,0,0,'2026-05-20 09:05:04'),(406,'Telecaller','leads.create','General',1,1,1,0,0,'2026-05-20 09:05:08'),(407,'Telecaller','leads.edit','General',1,1,1,0,0,'2026-05-20 09:05:10'),(408,'Telecaller','leads.delete','General',1,1,1,0,0,'2026-05-20 09:05:11'),(410,'Telecaller','comms.sms','General',1,1,1,0,0,'2026-05-20 09:05:14'),(411,'Telecaller','comms.email','General',1,1,1,0,0,'2026-05-20 09:05:16'),(412,'Telecaller','master.branches','General',0,0,0,0,0,'2026-05-20 04:48:26'),(413,'Telecaller','master.courses','General',1,1,1,0,0,'2026-05-20 09:05:19'),(414,'Telecaller','master.countries','General',1,1,1,0,0,'2026-05-20 09:05:20'),(415,'Telecaller','admin.users','General',0,0,0,0,0,'2026-05-20 04:48:26'),(416,'Telecaller','admin.export','General',1,1,1,0,0,'2026-05-20 09:05:22'),(417,'Telecaller','admin.settings','General',0,0,0,0,0,'2026-05-20 04:48:26'),(553,'Counselor','pipeline.view','General',1,1,1,0,0,'2026-05-20 14:23:40'),(554,'Telecaller','pipeline.view','General',1,1,1,0,0,'2026-05-20 14:23:40'),(556,'Manager','master.users','General',0,0,0,0,0,'2026-05-21 03:05:37'),(557,'Counselor','master.users','General',0,0,0,0,0,'2026-05-21 03:05:37'),(558,'Telecaller','master.users','General',0,0,0,0,0,'2026-05-21 03:05:37'),(602,'Super Admin','dashboard.view','General',1,1,1,1,1,'2026-05-21 12:10:10'),(603,'Super Admin','leads.workspace','General',1,1,1,1,1,'2026-05-21 12:10:10'),(604,'Super Admin','pipeline.view','General',1,1,1,1,1,'2026-05-21 12:10:10'),(605,'Super Admin','communication','General',1,1,1,1,1,'2026-05-21 12:10:10'),(606,'Super Admin','followups','General',1,1,1,1,1,'2026-05-21 12:10:10'),(607,'Super Admin','ai.automation','General',1,1,1,1,1,'2026-05-21 12:10:10'),(608,'Super Admin','reports.leads','General',1,1,1,1,1,'2026-05-21 12:10:10'),(609,'Super Admin','audit.logs','General',1,1,1,1,1,'2026-05-21 12:10:10'),(610,'Super Admin','masters','General',1,1,1,1,1,'2026-05-21 12:10:10'),(611,'Super Admin','settings','General',1,1,1,1,1,'2026-05-21 12:10:10'),(612,'Super Admin','admin.users','General',1,1,1,1,1,'2026-05-21 12:10:10'),(622,'Manager','leads.workspace','General',1,1,1,0,1,'2026-05-21 12:10:10'),(623,'Manager','pipeline.view','General',1,1,1,0,1,'2026-05-21 12:10:10'),(624,'Manager','communication','General',1,1,1,1,1,'2026-05-21 12:10:10'),(625,'Manager','followups','General',1,1,1,1,1,'2026-05-21 12:10:10'),(626,'Manager','ai.automation','General',1,1,1,1,1,'2026-05-21 12:10:10'),(627,'Manager','reports.leads','General',1,0,0,0,1,'2026-05-21 12:10:10'),(628,'Manager','audit.logs','General',1,0,0,0,0,'2026-05-21 12:10:10'),(635,'Telecaller','leads.workspace','General',1,1,1,0,0,'2026-05-21 12:10:10'),(636,'Telecaller','communication','General',1,1,1,1,0,'2026-05-21 12:10:10'),(637,'Telecaller','followups','General',1,1,1,1,0,'2026-05-21 12:10:10'),(639,'Super Admin','leads.delete','General',1,1,1,1,1,'2026-05-23 14:06:47'),(640,'Admin','leads.delete','General',1,1,1,1,1,'2026-05-23 14:06:48');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission_map`
--

DROP TABLE IF EXISTS `role_permission_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission_map` (
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `fk_rpm_permission` (`permission_id`),
  CONSTRAINT `fk_rpm_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rpm_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission_map`
--

LOCK TABLES `role_permission_map` WRITE;
/*!40000 ALTER TABLE `role_permission_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permission_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_feature` (`role`,`feature_name`),
  UNIQUE KEY `idx_role_feature` (`role`,`feature_name`),
  UNIQUE KEY `unique_role_key` (`role`,`permission_key`),
  UNIQUE KEY `role_key_unique` (`role`,`permission_key`),
  UNIQUE KEY `idx_role_permission` (`role`,`permission_key`),
  UNIQUE KEY `idx_role_feature_key` (`role`,`feature_name`,`permission_key`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,'branch-admin','View Operational Analytics Dashboard',NULL,1,'2026-05-19 21:13:14'),(2,'branch-admin','View Branch-Wide Performance Stats',NULL,1,'2026-05-19 21:13:14'),(3,'branch-admin','View Leads Directory',NULL,1,'2026-05-19 21:13:14'),(4,'branch-admin','Create Inbound Lead Profiles',NULL,1,'2026-05-19 21:13:14'),(5,'branch-admin','Modify Lead Parameters',NULL,1,'2026-05-19 21:13:14'),(6,'branch-admin','WhatsApp Cloud Integration Gateway',NULL,1,'2026-05-19 21:13:14'),(7,'branch-admin','SMS Channel Broadcast Engines',NULL,1,'2026-05-19 21:13:14'),(8,'branch-admin','Official Mail Relay Triggers',NULL,1,'2026-05-19 21:13:14'),(9,'branch-admin','Manage Corporate Branches',NULL,1,'2026-05-19 21:13:14'),(10,'branch-admin','Manage Academic Course Catalogue',NULL,1,'2026-05-19 21:13:14'),(11,'branch-admin','Manage Geopolitical Countries Matrix',NULL,1,'2026-05-19 21:13:14'),(12,'branch-admin','Export Ledger Records (CSV/XLS)',NULL,1,'2026-05-19 21:13:14'),(13,'manager','View Operational Analytics Dashboard',NULL,1,'2026-05-19 21:13:14'),(14,'manager','View Branch-Wide Performance Stats',NULL,1,'2026-05-19 21:13:14'),(15,'manager','View Leads Directory',NULL,1,'2026-05-19 21:13:14'),(16,'manager','Create Inbound Lead Profiles',NULL,1,'2026-05-19 21:13:14'),(17,'manager','Modify Lead Parameters',NULL,1,'2026-05-19 21:13:14'),(18,'manager','WhatsApp Cloud Integration Gateway',NULL,1,'2026-05-19 21:13:14'),(19,'manager','SMS Channel Broadcast Engines',NULL,1,'2026-05-19 21:13:14'),(20,'manager','Official Mail Relay Triggers',NULL,1,'2026-05-19 21:13:14'),(21,'manager','Export Ledger Records (CSV/XLS)',NULL,1,'2026-05-19 21:13:14'),(22,'counselor','View Operational Analytics Dashboard',NULL,1,'2026-05-19 21:13:14'),(23,'counselor','View Leads Directory',NULL,1,'2026-05-19 21:13:14'),(24,'counselor','Create Inbound Lead Profiles',NULL,1,'2026-05-19 21:13:14'),(25,'counselor','Modify Lead Parameters',NULL,1,'2026-05-19 21:13:14'),(26,'counselor','Manage Academic Course Catalogue',NULL,1,'2026-05-19 21:13:14'),(27,'telecaller','View Leads Directory',NULL,1,'2026-05-19 21:13:14'),(28,'telecaller','Create Inbound Lead Profiles',NULL,1,'2026-05-19 21:13:14'),(29,'telecaller','Modify Lead Parameters',NULL,1,'2026-05-19 21:13:14');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_system_role` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin',1,'2026-05-19 10:47:40'),(2,'Branch Admin',1,'2026-05-19 10:47:40'),(3,'Manager',1,'2026-05-19 10:47:40'),(4,'Counselor',1,'2026-05-19 10:47:40'),(5,'Tele Caller',1,'2026-05-19 10:47:40');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int NOT NULL DEFAULT '1',
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_address` text COLLATE utf8mb4_unicode_ci,
  `company_website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_url` text COLLATE utf8mb4_unicode_ci,
  `agency_contact_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agency_contact_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_call_recording_enabled` tinyint(1) DEFAULT '0',
  `telephony_provider` enum('none','exotel','twilio') COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `is_sms_template_enabled` tinyint(1) DEFAULT '0',
  `is_whatsapp_automation_enabled` tinyint(1) DEFAULT '0',
  `is_email_trigger_enabled` tinyint(1) DEFAULT '0',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'WebGyor Media Agency','+91 6787678987','admin@webgyor.com','Surabhi Nagar , West Nadakkavu','https://webgyor.com','/uploads/93a81a6c50d47c0386285bd4c60ecfe4','Shaji Mukundan','contact@webgyor.com',0,'none',0,0,1,'2026-05-27 05:57:22');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_ur_role` (`role_id`),
  CONSTRAINT `fk_ur_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ur_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (21,4);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` varchar(50) NOT NULL,
  `is_super_admin` tinyint(1) NOT NULL DEFAULT '0',
  `is_branch_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `designation` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `password` varchar(255) NOT NULL,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `reset_password_expires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Anil ','anil.c@webgyor.com','9846012345','Counselor',0,0,'active','','','2026-05-19 16:32:27','2026-03-24 06:12:05','$2b$10$8ZnCRSNRgL8Xp2s7PN.qNeQKyCGp7YYofNE3dSDrE.zoLs2ubhlQ6',NULL,NULL),(2,'SHAJI','shaji.m@webgyor.com','','Manager',0,0,'active','','','2026-05-21 09:01:35','2026-03-24 06:13:45','$2b$10$I1tQs8IahOkzaeVo9CFGiur/aSUObBb8ElMw..2w/rGQxOCVvjvrC',NULL,NULL),(3,'Ajith Kumar','webgyorc@gmail.com','6238370210','Super Admin',1,0,'active','','','2026-05-27 06:46:34','2026-03-24 10:38:05','$2b$10$q1tN1.rxKc024sJO3jZlTuzqoiMH5shO41loljHjR6CiS5Zuq5z2K','1d97350939ff868b14d5afb3246644c91819a34b','2026-04-12 16:33:50'),(6,'Madhu','madhu.c@webgyor.com','','Manager',0,0,'active','','','2026-05-21 21:09:59','2026-03-24 20:47:36','$2b$10$OjOonN3WUBbmJiYtplOwfuI6SYj1Xj61/ChjTNT800nb4ANR9F7Pa',NULL,NULL),(7,'Ramya','ramya.t@webgyor.com','','Counselor',0,0,'active','','Marketing',NULL,'2026-04-13 06:05:46','$2b$10$Vv4eYRLccPQSW6VWIN4M4.TnH1p7SFfBTPCEjSLNhC/X5a9G1D5NG',NULL,NULL),(9,'Suman','suman.b@webgyor.com','','Counselor',0,1,'active','','','2026-05-21 21:06:57','2026-05-19 10:50:30','$2b$10$G6c9tHqn7gGqHW2TPwUtx.dyCA1t7twaQthnfwGoxjTpPMANp4QSC',NULL,NULL),(20,'Kavya ','kavya.m@webgyor.com','','Counselor',0,0,'active','Branch Manager','Administration','2026-05-21 15:23:29','2026-05-19 11:05:15','$2b$10$7gV6Wg9l5jcBuEd7znqs2eLBsnmoO4Urm/8ZJas79NBQAu1B7sTkm',NULL,NULL),(21,'Ragesh ','ragesh.c@webgyor.com','','Counselor',0,0,'active','Senior Counselor','Academic Operations','2026-05-20 08:45:21','2026-05-19 11:05:15','$2b$10$x.bHp7H8/3Kk3TKw6EUuqOpi9kL27s9.r5hSLQ3u8q088sfl7G2vW',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-27  7:40:45
